# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""
VectArt Animation - Orchestral animation tools for collections of mesh and curve objects.

This extension uses the blender_manifest.toml for metadata (no bl_info needed).
Includes geometry nodes procedural animation presets.
"""

from . import properties, operators, panels, geometry_nodes


def register():
    properties.register()
    operators.register()
    panels.register()


def unregister():
    panels.unregister()
    operators.unregister()
    properties.unregister()
