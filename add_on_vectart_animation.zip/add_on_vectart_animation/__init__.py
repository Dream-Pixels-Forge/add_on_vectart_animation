bl_info = {
    "name": "VectArt Animation",
    "author": "Dimona Patrick",
    "version": (1, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > VectArt Animation",
    "description": "Animation tools for VectArt curves and objects",
    "category": "Animation",
}

import bpy
import math
import random
from bpy.props import (StringProperty,
                      BoolProperty,
                      EnumProperty,
                      FloatProperty,
                      FloatVectorProperty,
                      IntProperty,
                      CollectionProperty,
                      PointerProperty)
from bpy.types import (Operator,
                      Panel,
                      PropertyGroup,
                      UIList)
from mathutils import Vector, Euler
import time



def get_bounding_box_dimensions(obj):
    """Get object's bounding box dimensions and center"""
    bbox = obj.bound_box
    bbox_vertices = [Vector(v) @ obj.matrix_world for v in bbox]
    
    min_x = min(v.x for v in bbox_vertices)
    max_x = max(v.x for v in bbox_vertices)
    min_y = min(v.y for v in bbox_vertices)
    max_y = max(v.y for v in bbox_vertices)
    min_z = min(v.z for v in bbox_vertices)
    max_z = max(v.z for v in bbox_vertices)
    
    dimensions = Vector((max_x - min_x, max_y - min_y, max_z - min_z))
    center = Vector(((max_x + min_x)/2, (max_y + min_y)/2, (max_z + min_z)/2))
    
    return dimensions, center

def check_collision(obj1, obj2, margin=0.1, epsilon=1e-5):
    """Check if two objects' bounding boxes collide with improved accuracy and stability"""
    dims1, center1 = get_bounding_box_dimensions(obj1)
    dims2, center2 = get_bounding_box_dimensions(obj2)

    dims1 = dims1 * (1 + margin)
    dims2 = dims2 * (1 + margin)

    distance_vector = center1 - center2

    # Add epsilon to avoid floating-point edge cases
    return (
        abs(distance_vector.x) * 2 < (dims1.x + dims2.x + epsilon) and
        abs(distance_vector.y) * 2 < (dims1.y + dims2.y + epsilon) and
        abs(distance_vector.z) * 2 < (dims1.z + dims2.z + epsilon)
    )

def get_safe_position(obj, target_pos, other_objects, margin=0.1, max_attempts=100):
    """Find a safe position avoiding collisions with improved algorithm"""
    if not other_objects:
        return target_pos

    dims, _ = get_bounding_box_dimensions(obj)
    orig_pos = obj.location.copy()

    # 3D directions (including diagonals)
    directions = [
        Vector((1,0,0)), Vector((-1,0,0)), Vector((0,1,0)), Vector((0,-1,0)), Vector((0,0,1)), Vector((0,0,-1)),
        Vector((1,1,0)), Vector((1,-1,0)), Vector((-1,1,0)), Vector((-1,-1,0)),
        Vector((1,0,1)), Vector((1,0,-1)), Vector((-1,0,1)), Vector((-1,0,-1)),
        Vector((0,1,1)), Vector((0,1,-1)), Vector((0,-1,1)), Vector((0,-1,-1)),
        Vector((1,1,1)), Vector((1,1,-1)), Vector((1,-1,1)), Vector((1,-1,-1)),
        Vector((-1,1,1)), Vector((-1,1,-1)), Vector((-1,-1,1)), Vector((-1,-1,-1))
    ]

    # Try multiple distances, increasing
    base_distance = max(dims) * (1 + margin)
    distances = [base_distance * (i+1) for i in range(6)]

    attempt = 0
    for distance in distances:
        for direction in directions:
            test_pos = target_pos + direction.normalized() * distance
            obj.location = test_pos
            collision = False
            for other in other_objects:
                if other != obj and check_collision(obj, other, margin):
                    collision = True
                    break
            if not collision:
                obj.location = orig_pos
                return test_pos
            attempt += 1
            if attempt > max_attempts:
                break
        if attempt > max_attempts:
            break

    # Try random jitter as a last resort
    for _ in range(20):
        jitter = Vector((random.uniform(-1,1), random.uniform(-1,1), random.uniform(-1,1))) * base_distance * 2
        test_pos = target_pos + jitter
        obj.location = test_pos
        collision = False
        for other in other_objects:
            if other != obj and check_collision(obj, other, margin):
                collision = True
                break
        if not collision:
            obj.location = orig_pos
            return test_pos

    # Fallback: try shifting along the largest axis
    axis = max(range(3), key=lambda i: dims[i])
    for sign in [-1, 1]:
        test_pos = target_pos.copy()
        test_pos[axis] += sign * base_distance * 4
        obj.location = test_pos
        collision = False
        for other in other_objects:
            if other != obj and check_collision(obj, other, margin):
                collision = True
                break
        if not collision:
            obj.location = orig_pos
            return test_pos

    # As a last resort, increase margin and try again (recursive, but limited)
    if margin < 0.5:
        return get_safe_position(obj, target_pos, other_objects, margin=margin+0.1, max_attempts=max_attempts)

    obj.location = orig_pos
    return target_pos

def apply_transform_with_collision(obj, data, frame, props, animated_objects):
    """Apply transforms with collision detection"""
    # Calculate position with collision detection if enabled
    if props.use_collision_detection:
        if props.use_local_axis:
            world_loc = obj.matrix_world @ Vector(data['loc'])
            safe_pos = get_safe_position(obj, world_loc, animated_objects, props.collision_margin)
            local_loc = obj.matrix_world.inverted() @ safe_pos
            obj.location = local_loc
        else:
            safe_pos = get_safe_position(obj, data['loc'], animated_objects, props.collision_margin)
            obj.location = safe_pos
    else:
        if props.use_local_axis:
            local_loc = obj.matrix_world.inverted() @ Vector(data['loc'])
            obj.location = local_loc
        else:
            obj.location = data['loc']
    
    # Apply other transforms
    obj.scale = data['scale']
    if 'rot' in data:
        obj.rotation_euler = data['rot']
    
    # Handle curve bevel
    if obj.type == 'CURVE' and 'bevel' in data and data['bevel'] is not None:
        obj.data.bevel_depth = data['bevel']
        obj.data.keyframe_insert("bevel_depth", frame=frame)
    
    # Insert keyframes
    obj.keyframe_insert(data_path="location", frame=frame)
    obj.keyframe_insert(data_path="scale", frame=frame)
    if 'rot' in data:
        obj.keyframe_insert(data_path="rotation_euler", frame=frame)

def update_collision_settings(self, context):
    """Update function for collision-related settings"""
    # Refresh the viewport to show collision changes immediately
    if context.area:
        context.area.tag_redraw()
    return None

def random_mech_angle():
    # Returns a random choice of ±90, ±180, ±360 degrees in radians
    return math.radians(random.choice([90, -90, 180, -180, 360, -360]))

def random_origami_axis():
    # Returns a random axis as a tuple (x, y, z) with one 1 or -1, others 0
    axes = [(1,0,0), (0,1,0), (0,0,1), (-1,0,0), (0,-1,0), (0,0,-1)]
    return random.choice(axes)

def random_origami_angle():
    # Origami folds: ±90 or ±180 degrees
    return math.radians(random.choice([90, -90, 180, -180]))

def build_origami_sequence(orig_scale, orig_rot, orig_loc, steps=4):
    """Builds a complex origami sequence with random axes and folds"""
    seq = []
    scale = orig_scale.copy()
    rot = orig_rot.copy()
    loc = orig_loc.copy()
    for i in range(steps):
        axis = random_origami_axis()
        angle = random_origami_angle()
        # Fold: scale down one axis, rotate
        fold_scale = Vector([
            scale[j] * (0.2 if axis[j] != 0 else 1.0)
            for j in range(3)
        ])
        fold_rot = rot.copy()
        for j in range(3):
            if axis[j] != 0:
                fold_rot[j] += angle
        seq.append(('SCALE', scale.copy(), fold_scale.copy()))
        seq.append(('ROTATION', rot.copy(), fold_rot.copy()))
        scale = fold_scale
        rot = fold_rot
    # Unfold: reverse the folds
    for i in range(steps):
        axis = random_origami_axis()
        angle = random_origami_angle()
        unfold_scale = Vector([
            orig_scale[j] if axis[j] != 0 else scale[j]
            for j in range(3)
        ])
        unfold_rot = rot.copy()
        for j in range(3):
            if axis[j] != 0:
                unfold_rot[j] -= angle
        seq.append(('SCALE', scale.copy(), unfold_scale.copy()))
        seq.append(('ROTATION', rot.copy(), unfold_rot.copy()))
        scale = unfold_scale
        rot = unfold_rot
    # Final pop and restore
    seq.append(('SCALE', scale.copy(), orig_scale.copy()))
    seq.append(('ROTATION', rot.copy(), orig_rot.copy()))
    seq.append(('LOCATION', loc.copy(), orig_loc.copy()))
    return seq

def calculate_sequence_timing(props, index, total_elements, action_index=0):
    """Calculate timing for sequential animation with improved orchestration.
    Args:
        props: Animation properties
        index: Object index
        total_elements: Total number of objects
        action_index: Current action index (0=scale, 1=rotate, 2=move, etc)
    Returns:
        start_time: When this element/action should start animating (int, frame)
    """
    # Base duration for each object's action
    base_duration = props.frames_per_object

    # Calculate delay per object
    if props.delay_mode == 'NONE':
        element_delay = 0
    elif props.delay_mode == 'SEQUENTIAL':
        element_delay = props.delay_amount
    elif props.delay_mode == 'RANDOM':
        random.seed(props.random_seed + index + action_index * 1000)
        element_delay = random.uniform(0, props.delay_amount)
    elif props.delay_mode == 'OVERLAP':
        # Overlap is a percentage of the action duration
        overlap = max(0.0, min(props.overlap_div, 1.0))
        element_delay = base_duration * (1 - overlap)
    else:
        element_delay = 0

    # The object's own offset in the sequence
    element_start = index * (base_duration + element_delay)
    
    # The action's offset in the sequence
    musicality = props.musicality
    action_offset = action_index * (total_elements * (base_duration + element_delay) * musicality)

    element_start = index * (base_duration + element_delay)
    start_time = int(round(action_offset + element_start))
    return start_time

def apply_preset_animation(self, context, obj, start_frame, preset_type):
    """Apply preset animation to an object"""
    props = context.scene.vectart_animation_props
    
    # Store original transforms
    orig_loc = obj.location.copy()
    orig_rot = obj.rotation_euler.copy()
    orig_scale = obj.scale.copy()
    
    # Define animation sequences for different presets
    preset_sequences = {
        'ROBOTIC_UNFOLD': [
            ('SCALE', Vector((0, 0, 0)), Vector((0.2, 0.2, 0.2))),
            ('LOCATION', Vector((random.uniform(-4, 4), random.uniform(-4, 4), random.uniform(-2, 2))), obj.location.copy()),
            ('SCALE', Vector((0.2, 0.2, 0.2)), Vector((1.2, 1.2, 1.2))),
            ('ROTATION', Vector((0, 0, 0)), Vector((random_mech_angle(), random_mech_angle(), 0))),
            ('SCALE', Vector((1.2, 1.2, 1.2)), orig_scale),
            ('ROTATION', Vector((random_mech_angle(), 0, 0)), orig_rot),
            ('LOCATION', obj.location.copy(), orig_loc)
        ],
        'ROBOTIC_TRANSFORM': [
            ('LOCATION', Vector((random.uniform(-6, 6), random.uniform(-6, 6), random.uniform(2, 6))), obj.location.copy()),
            ('SCALE', Vector((0.1, 0.1, 0.1)), Vector((1.5, 1.5, 1.5))),
            ('ROTATION', Vector((0, 0, 0)), Vector((random_mech_angle(), random_mech_angle(), random_mech_angle()))),
            ('SCALE', Vector((1.5, 1.5, 1.5)), orig_scale),
            ('ROTATION', Vector((random_mech_angle(), 0, 0)), orig_rot),
            ('LOCATION', obj.location.copy(), orig_loc)
        ],
        'TECH_ASSEMBLY': [
            ('LOCATION', Vector((random.uniform(-8, 8), random.uniform(-8, 8), random.uniform(4, 8))), Vector(props.location_start)),
            ('SCALE', Vector((0, 0, 0)), Vector((0.5, 0.5, 0.5))),
            ('ROTATION', Vector((random_mech_angle(), 0, 0)), Vector((0, random_mech_angle(), 0))),
            ('SCALE', Vector((0.5, 0.5, 0.5)), orig_scale),
            ('LOCATION', Vector(props.location_start), orig_loc),
            ('ROTATION', Vector((0, random_mech_angle(), 0)), orig_rot)
        ],
        'MECH_STARTUP': [
            ('SCALE', Vector((0.05, 0.05, 0.05)), Vector((1.1, 1.1, 1.1))),
            ('ROTATION', Vector((0, 0, 0)), Vector((0, random_mech_angle(), 0))),
            ('SCALE', Vector((1.1, 1.1, 1.1)), Vector((0.95, 0.95, 0.95))),
            ('SCALE', Vector((0.95, 0.95, 0.95)), orig_scale),
            ('LOCATION', obj.location.copy(), orig_loc),
            ('ROTATION', obj.rotation_euler.copy(), orig_rot)
        ],  
        'ORIGAMI': (build_origami_sequence(orig_scale, orig_rot, orig_loc, steps=4)),
        
        'HOLOGRAPHIC_APPEAR': [
            # Appear from above, scale up, fade in (simulate with scale)
            ('SCALE', Vector((0, 0, 0)), Vector((0.7, 0.7, 0.7))),
            ('LOCATION', Vector((0, 0, 8)), Vector((0, 0, 2))),
            ('SCALE', Vector((0.7, 0.7, 0.7)), orig_scale),
            ('LOCATION', Vector((0, 0, 2)), orig_loc),
            ('ROTATION', Vector((0, 0, 0)), orig_rot)
        ],
        'GLITCH_APPEAR': [
            # Appear with random jumps and scale flickers
            ('SCALE', Vector((0, 0, 0)), Vector((0.5, 0.5, 0.5))),
            ('LOCATION', Vector((random.uniform(-2, 2), random.uniform(-2, 2), random.uniform(-2, 2))), obj.location.copy()),
            ('SCALE', Vector((0.5, 0.5, 0.5)), Vector((1.2, 1.2, 1.2))),
            ('LOCATION', Vector((random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1))), orig_loc),
            ('SCALE', Vector((1.2, 1.2, 1.2)), orig_scale),
            ('ROTATION', Vector((random.uniform(-math.pi, math.pi), 0, 0)), orig_rot)
        ],
        'ASSEMBLE': [
            # Dramatic assembly from all directions
            ('SCALE', Vector((random.uniform(0.1, 0.3), random.uniform(0.1, 0.3), random.uniform(0.1, 0.3))), Vector((1.2, 1.2, 1.2))),
            ('LOCATION', Vector((random.uniform(-10, 10), random.uniform(-10, 10), random.uniform(5, 15))), orig_loc),
            ('SCALE', Vector((1.2, 1.2, 1.2)), orig_scale),
            ('ROTATION', Vector((random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi))), orig_rot)
        ],
        'MAGNETIC': [
            # Objects "snap" in from far, with a bounce
            ('LOCATION', Vector((random.uniform(-12, 12), random.uniform(-12, 12), random.uniform(-12, 12))), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 2))),
            ('SCALE', Vector((0.8, 0.8, 0.8)), Vector((1.1, 1.1, 1.1))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 2)), orig_loc),
            ('SCALE', Vector((1.1, 1.1, 1.1)), orig_scale),
            ('ROTATION', Vector((random.uniform(-math.pi/2, math.pi/2), random.uniform(-math.pi/2, math.pi/2), random.uniform(-math.pi/2, math.pi/2))), orig_rot)
        ],
        'EXPLODE': [
            # Dramatic scale up, then explode outwards, then fade
            ('SCALE', orig_scale, Vector((1.5, 1.5, 1.5))),
            ('LOCATION', orig_loc, Vector((orig_loc.x + random.uniform(-8, 8), orig_loc.y + random.uniform(-8, 8), orig_loc.z + random.uniform(-8, 8)))),
            ('SCALE', Vector((1.5, 1.5, 1.5)), Vector((0.1, 0.1, 0.1))),
            ('ROTATION', orig_rot, Vector((random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi))))
        ]
    }
    
    sequence = preset_sequences.get(preset_type)
    if not sequence:
        print(f"Unknown preset type: {preset_type}")
        return False
        
    try:
        # Clear existing animation
        if obj.animation_data:
            obj.animation_data_clear()
        obj.animation_data_create()
        
        current_start = 0
        # Apply each transformation in sequence
        for action_index, (action_type, start_value, end_value) in enumerate(sequence):
            current_start = start_frame + calculate_sequence_timing(
                props, obj.get('animation_index', 0), 
                len(context.selected_objects), 
                action_index
            )
            
            # Create keyframes for the transformation
            if action_type == 'SCALE':
                obj.scale = start_value
                obj.keyframe_insert(data_path="scale", frame=current_start)
                
                obj.scale = end_value
                obj.keyframe_insert(data_path="scale", frame=current_start + props.frames_per_object)
                
            elif action_type == 'ROTATION':
                obj.rotation_euler = start_value
                obj.keyframe_insert(data_path="rotation_euler", frame=current_start)
                
                obj.rotation_euler = end_value
                obj.keyframe_insert(data_path="rotation_euler", frame=current_start + props.frames_per_object)
                
            elif action_type == 'LOCATION':
                obj.location = start_value
                obj.keyframe_insert(data_path="location", frame=current_start)
                
                obj.location = end_value
                obj.keyframe_insert(data_path="location", frame=current_start + props.frames_per_object)
                
        # Handle curve bevel if object is a curve
        if obj.type == 'CURVE':
            if hasattr(obj.data, "bevel_depth"):
                obj.data.bevel_depth = 0.0
                obj.data.keyframe_insert("bevel_depth", frame=current_start)
                obj.data.bevel_depth = props.extrude_end
                obj.data.keyframe_insert("bevel_depth", frame=current_start + props.frames_per_object)
    
        # Apply easing to the animation
        if obj.animation_data and obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                for keyframe in fcurve.keyframe_points:
                    keyframe.interpolation = props.preset_animation_interpolation
                    keyframe.easing = props.preset_animation_easing
                
        return True
        
    except Exception as e:
        self.report({'WARNING'}, f"Error creating animation: {str(e)}")
        return False

def apply_animation_easing(obj, props, objects):
    """Apply easing to animation curves"""
    if not obj.animation_data or not obj.animation_data.action:
        return
    
    for fcurve in obj.animation_data.action.fcurves:
        for keyframe in fcurve.keyframe_points:
            keyframe.interpolation = props.preset_animation_interpolation
            
            # Apply easing if not linear
            if props.animation_easing != 'LINEAR':
                keyframe.easing = props.preset_animation_easing
                
        fcurve.update()

    return objects

def create_keyframe(obj, data_path, value, frame, interpolation='LINEAR'):
    """Helper function to create keyframes with proper interpolation"""
    obj.keyframe_insert(data_path=data_path, frame=frame)
    if obj.animation_data and obj.animation_data.action:
        for fc in obj.animation_data.action.fcurves:
            if fc.data_path == data_path:
                for kf in fc.keyframe_points:
                    if kf.co.x == frame:
                        kf.interpolation = interpolation

def create_transform_keyframes(obj, start_frame, props, transform_type, start_value, end_value):
    """Create keyframes for a transformation with proper timing"""
    data_paths = {
        'SCALE': 'scale',
        'ROTATION': 'rotation_euler',
        'LOCATION': 'location'
    }
    
    data_path = data_paths.get(transform_type)
    if not data_path:
        return
        
    # Calculate frames
    frames_per_obj = props.frames_per_object
    pause_duration = props.delay_amount
    
    # Set initial state
    setattr(obj, data_path, start_value)
    create_keyframe(obj, data_path, start_value, start_frame, props.preset_animation_interpolation)
    
    # Set animated state
    mid_frame = start_frame + frames_per_obj/2
    setattr(obj, data_path, end_value)
    create_keyframe(obj, data_path, end_value, mid_frame, props.preset_animation_interpolation)
    
    # Set pause state
    end_frame = start_frame + frames_per_obj + pause_duration
    create_keyframe(obj, data_path, end_value, end_frame, props.preset_animation_interpolation)

def validate_collection_name(name):
    """Validate if collection name is allowed"""
    forbidden_names = {'cameras', 'lights', 'bg'}
    return name.lower() not in forbidden_names

# Property Groups
class VectartCollectionItem(PropertyGroup):
    name: StringProperty(default="Collection")
    active: BoolProperty(default=True)
    collection: PointerProperty(type=bpy.types.Collection)

class PresetItem(PropertyGroup):
    name: StringProperty(default="Preset")
    preset_id: StringProperty()
    icon: StringProperty(default="NONE")
    description: StringProperty()

class VectartAnimationProperties(PropertyGroup):
    # Collection Management
    collections: CollectionProperty(type=VectartCollectionItem)
    active_collection_index: IntProperty()
    
    # Animation Timing
    animation_start_frame: IntProperty(
        name="Start Frame",
        default=1,
        min=1
    )
    auto_duration: BoolProperty(
        name="Auto Duration",
        default=True
    )
    frames_per_object: IntProperty(
        name="Frames Per Object",
        default=6,
        min=1
    )
    duration: IntProperty(
        name="Duration",
        default=50,
        min=1
    )

    delay_mode: EnumProperty(
        name="Delay Mode",
        items=[
            ('NONE', "None", "No delay between objects"),
            ('SEQUENTIAL', "Sequential", " delay between objects"),
            ('RANDOM', "Random", "Random delay between objects"),
            ('OVERLAP', "Overlap", "Objects overlap animation")
        ],
        default='SEQUENTIAL'
    )
    delay_amount: FloatProperty(
        name="Delay",
        description="Delay amount in frames",
        default=5.0,
        min=0.0
    )
    random_seed: IntProperty(
        name="Random Seed",
        description="Seed for random delay generation",
        default=1234,
        min=1
    )
    overlap_div: FloatProperty(
        name="Overlap",
        description="Amount of overlap between animations (0.1 = minimal overlap, 1.0 = full overlap)",
        default=0.85,
        min=0.1,
        max=1.0,
        precision=2
    )

    animation_preset: EnumProperty(
        name="Animation Preset",
        items=[
            ('ROBOTIC_UNFOLD', "Robotic Unfold", "Robotic unfolding animation"),
            ('ROBOTIC_TRANSFORM', "Robotic Transform", "Complex transformation sequence"),
            ('TECH_ASSEMBLY', "Tech Assembly", "Technical assembly animation"),
            ('MECH_STARTUP', "Mech Startup", "Mechanical startup sequence"),
            ('ORIGAMI', "Origami", "Complex origami folding and unfolding animation"),
            ('HOLOGRAPHIC_APPEAR', "Holographic", "Holographic appearance effect"),
            ('GLITCH_APPEAR', "Glitch", "Glitch appearance effect"),
            ('ASSEMBLE', "Assemble", "Parts assembly animation"),
            ('MAGNETIC', "Magnetic", "Magnetic attraction animation"),
            ('EXPLODE', "Explode", "Object explosion animation"),
        ],
        default='ROBOTIC_UNFOLD'
    )
 
    animation_interpolation: EnumProperty(
        name="Interpolation",
        items=[
            ('LINEAR', "Linear", "Linear interpolation"),
            ('BEZIER', "Bezier", "Bezier curve interpolation"),
            ('CONSTANT', "Constant", "No interpolation")
        ],
        default='LINEAR'
    )
    
    # Animation Flow
    animation_velocity: EnumProperty(
        name="Velocity",
        items=[
            ('UNIFORM', "Uniform", "Constant speed"),
            ('ACCELERATE', "Accelerate", "Increasing speed"),
            ('DECELERATE', "Decelerate", "Decreasing speed")
        ],
        default='ACCELERATE'
    )

    layer_animation_order: EnumProperty(
        name="Layer Order",
        items=[
            ('TOP_DOWN', "Top Down", "Animate from top layer to bottom"),
            ('BOTTOM_UP', "Bottom Up", "Animate from bottom layer to top"),
            ('SIMULTANEOUS', "Simultaneous", "Animate all layers at once")
        ],
        default='BOTTOM_UP'
    )

    use_local_axis: BoolProperty(
        name="Use Local Axis",
        description="Use object's local axis for animations",
        default=False
    )

    animation_mode: EnumProperty(
        name="Animation Mode",
        items=[
            ('DEFAULT', "Default", "Standard keyframe animation"),
            ('PRESET', "Preset", "Predefined animation presets"),
            
        ],
        default='DEFAULT'
    )

    default_type: EnumProperty(
        name="Animation Type",
        items=[
            ('SCALE', "Scale", "Scale animation"),
            ('ROTATE', "Rotate", "Rotation animation"),
            ('LOCATION', "Location", "Location animation"),
            ('EXTRUDE', "Extrude", "Extrude animation")
        ],
        default='SCALE'
    )

    # Animation combination toggles
    use_scale: BoolProperty(
        name="Scale",
        description="Apply scale animation",
        default=True
    )
    use_rotation: BoolProperty(
        name="Rotation",
        description="Apply rotation animation",
        default=False
    )
    use_location: BoolProperty(
        name="Location",
        description="Apply location animation",
        default=False
    )
    use_extrude: BoolProperty(
        name="Extrude",
        description="Apply extrude animation (curves only)",
        default=False
    )
    
    # Animation timing offsets
    scale_offset: IntProperty(
        name="Scale Offset",
        description="Frame offset for scale animation",
        default=0,
        min=0
    )
    rotation_offset: IntProperty(
        name="Rotation Offset",
        description="Frame offset for rotation animation",
        default=10,
        min=0
    )
    location_offset: IntProperty(
        name="Location Offset",
        description="Frame offset for location animation",
        default=0,
        min=0
    )
    extrude_offset: IntProperty(
        name="Extrude Offset",
        description="Frame offset for extrude animation",
        default=0,
        min=0
    )
    
    # Preset management
    presets: CollectionProperty(type=PresetItem)
    active_preset_index: IntProperty(default=0)

    # Scale Settings
    scale_final: FloatVectorProperty(
        name="Final Scale",
        default=(1.0, 1.0, 1.0),
        subtype='XYZ'
    )
    scale_min: FloatVectorProperty(
        name="Start Scale",
        default=(0.0, 0.0, 0.0),
        subtype='XYZ'
    )
    maintain_proportions: BoolProperty(
        name="Maintain Proportions",
        default=True
    )
    
    # Rotation Settings
    rotation_axis: EnumProperty(
        name="Rotation Axis",
        items=[
            ('X', "X", "Rotate around X axis"),
            ('Y', "Y", "Rotate around Y axis"),
            ('Z', "Z", "Rotate around Z axis")
        ],
        default='Z'
    )
    rotation_angle: FloatProperty(
        name="Angle",
        default=math.radians(360.0),
        subtype='ANGLE',
        unit='ROTATION'
    )
    rotation_direction: EnumProperty(
        name="Direction",
        items=[
            ('CW', "Clockwise", "Clockwise rotation"),
            ('CCW', "Counter-Clockwise", "Counter-clockwise rotation")
        ],
        default='CW'
    )
    
    # Location Settings
    use_relative_location: BoolProperty(
        name="Relative Movement",
        default=True
    )
    location_start: FloatVectorProperty(
        name="Start",
        default=(0.0, 0.0, 2.0),
        subtype='TRANSLATION'
    )
    location_end: FloatVectorProperty(
        name="End",
        default=(0.0, 0.0, 0.0),
        subtype='TRANSLATION'
    )
    
    # Extrude Settings
    extrude_start: FloatProperty(
        name="Start",
        default=0.0,
        min=0.0
    )
    extrude_end: FloatProperty(
        name="End",
        default=0.01,
        min=0.0
    )
    extrude_steps: IntProperty(
        name="Steps",
        default=10,
        min=1
    )

    paste_target_frame: IntProperty(
        name="Target Frame",
        description="Frame to start pasting reversed animation",
        default=60,
        min=1
    )
    use_collision_detection: BoolProperty(
        name="Use Collision Detection",
        description="Enable smart collision detection for animations",
        default=True,
        update=update_collision_settings
    )
    
    collision_margin: FloatProperty(
        name="Collision Margin",
        description="Extra space to maintain between objects",
        default=0.1,
        min=0.0,
        max=1.0,
        update=update_collision_settings
    )

    preset_animation_interpolation: EnumProperty(
        name="Interpolation",
        description="Animation interpolation type",
        items=[
            ('LINEAR', "Linear", "Linear interpolation"),
            ('BOUNCE', "Bounce", "Bounce interpolation"),
            ('ELASTIC', "Elastic", "Elastic interpolation"),
            ('BACK', "Back", "Back interpolation"),
            ('SINE', "Sine", "Sinusoidal interpolation"),
            ('EXPO', "Exponential", "Exponential interpolation"),
            ('CIRC', "Circular", "Strong and dramatic"),
        ],
        default='EXPO'
    )
    
    preset_animation_easing: EnumProperty(
        name="Easing",
        description="Animation easing type",
        items=[
            ('EASE_IN', "Ease In", "Ease in"),
            ('EASE_OUT', "Ease Out", "Ease out"),
            ('EASE_IN_OUT', "Ease In-Out", "Ease in and out")
        ],
        default='EASE_OUT'
    )

    musicality: FloatProperty(
        name="Musicality",
        description="Controls the overlap and orchestration of actions (higher = more overlap, lower = more sequential)",
        default=0.5,
        min=0.0,
        max=2.0,
        step=0.01,
        precision=2
    )


# Collection Operators
class VECTART_OT_AddCollection(Operator):
    bl_idname = "vectart.add_collection"
    bl_label = "Add Collection"
    bl_description = "Add selected collection to the list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if there's an active collection and if it's not already in the list
        if not context.collection:
            return False
            
        props = context.scene.vectart_animation_props
        # Check if the active collection is already in the list
        return not any(item.collection == context.collection for item in props.collections)

    def execute(self, context):
        props = context.scene.vectart_animation_props
        active_collection = context.collection

        if active_collection:
            # Create a new item in the collection list
            item = props.collections.add()
            # Set the collection reference
            item.collection = active_collection
            # Set the name (optional, if you want to keep track of a separate name)
            item.name = active_collection.name
            # Set as active by default
            item.active = True
            
            # Update the active index to point to the newly added item
            props.active_collection_index = len(props.collections) - 1
            
            self.report({'INFO'}, f"Added collection: {active_collection.name}")
            return {'FINISHED'}
        
        self.report({'WARNING'}, "No active collection to add")
        return {'CANCELLED'}

    def invoke(self, context, event):
        return self.execute(context)

class VECTART_OT_RemoveCollection(Operator):
    bl_idname = "vectart.remove_collection"
    bl_label = "Remove Collection"
    bl_description = "Remove selected collection from the list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = context.scene.vectart_animation_props
        # Check if there are any collections and if the index is valid
        return (props.collections and 
                len(props.collections) > 0 and 
                0 <= props.active_collection_index < len(props.collections))

    def execute(self, context):
        props = context.scene.vectart_animation_props
        index = props.active_collection_index

        try:
            # Get the collection name before removal for the report
            collection_name = props.collections[index].collection.name
            
            # Remove the collection from the list
            props.collections.remove(index)
            
            # Adjust the active index
            if len(props.collections) > 0:
                # If we removed the last item, adjust the index
                if index >= len(props.collections):
                    props.active_collection_index = len(props.collections) - 1
            else:
                # If no items left, set index to -1 or 0
                props.active_collection_index = -1
            
            self.report({'INFO'}, f"Removed collection: {collection_name}")
            return {'FINISHED'}
            
        except (IndexError, AttributeError) as e:
            self.report({'ERROR'}, f"Error removing collection: {str(e)}")
            return {'CANCELLED'}

    def invoke(self, context, event):
        return self.execute(context)


class VECTART_OT_ClearCollections(Operator):
    bl_idname = "vectart.clear_collections"
    bl_label = "Clear Collections"
    bl_description = "Remove all collections from the list"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        # Clear only the UI list
        props.collections.clear()
        
        return {'FINISHED'}

class VECTART_OT_RefreshCollections(Operator):
    bl_idname = "vectart.refresh_collections"
    bl_label = "Refresh Collections"
    bl_description = "Refresh collection list"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        # Clear existing collections
        props.collections.clear()
        
        # Excluded collection names (case-insensitive)
        excluded_names = ["cameras", "lights", "bg"]
        
        # Add scene collections, excluding the ones in the excluded list
        for collection in bpy.data.collections:
            # Skip collections with excluded names (case-insensitive)
            if collection.name.lower() in excluded_names:
                continue
                
            collection_item = props.collections.add()
            collection_item.name = collection.name
            collection_item.collection = collection
            
        return {'FINISHED'}

class VECTART_OT_SelectCollectionObjects(Operator):
    bl_idname = "vectart.select_collection_objects"
    bl_label = "Select Objects"
    bl_description = "Select objects in collection"
    bl_options = {'REGISTER', 'UNDO'}
    
    select_type: EnumProperty(
        items=[
            ('ALL', "All", "Select all objects"),
            ('CURVES', "Curves", "Select only curves"),
            ('MESHES', "Meshes", "Select only meshes")
        ],
        default='ALL'
    )
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        if props.active_collection_index >= 0:
            collection_item = props.collections[props.active_collection_index]
            if collection_item.collection:
                bpy.ops.object.select_all(action='DESELECT')
                
                for obj in collection_item.collection.objects:
                    if (self.select_type == 'ALL' or
                        (self.select_type == 'CURVES' and obj.type == 'CURVE') or
                        (self.select_type == 'MESHES' and obj.type == 'MESH')):
                        obj.select_set(True)
                        context.view_layer.objects.active = obj
                        
        return {'FINISHED'}

# Animation Operators
class VECTART_OT_DefaultAnimation(bpy.types.Operator):
    bl_idname = "vectart.default_animation"
    bl_label = "Create Animation"
    bl_description = "Create animation based on current settings"
    bl_options = {'REGISTER', 'UNDO'}

    def get_sorted_objects(self, context, objects):
        """Sort objects based on layer order setting"""
        props = context.scene.vectart_animation_props
        valid_objects = [obj for obj in objects if obj.type in {'MESH', 'CURVE'}]
            
        if props.layer_animation_order == 'TOP_DOWN':
            valid_objects.sort(key=lambda obj: obj.location.z, reverse=True)
        elif props.layer_animation_order == 'BOTTOM_UP':
            valid_objects.sort(key=lambda obj: obj.location.z)
            
        return valid_objects

    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        if props.active_collection_index < 0:
            self.report({'WARNING'}, "No collection selected")
            return {'CANCELLED'}
            
        collection_item = props.collections[props.active_collection_index]
        if not collection_item.collection:
            self.report({'WARNING'}, "Invalid collection")
            return {'CANCELLED'}
            
        objects = self.get_sorted_objects(context, collection_item.collection.objects)
        if not objects:
            self.report({'WARNING'}, "No objects in collection")
            return {'CANCELLED'} 

        try:
            # Calculate total duration and frame settings
            if props.auto_duration:
                # Auto mode: each object gets its own frames_per_object duration
                object_duration = props.frames_per_object
                
            else:
                # Manual mode: all objects share the same total duration
                object_duration = props.duration
                

            # Calculate delays
            delays = self.calculate_delays(props, len(objects))
            
            # Initialize list for animated objects (for collision detection)
            animated_objects = []

            # Create animations
            for i, obj in enumerate(objects):
                start_frame = int(round(props.animation_start_frame + delays[i]))
                end_frame = int(round(start_frame + object_duration))

                # Calculate mid-frame for velocity curves (always integer)
                if props.animation_velocity == 'ACCELERATE':
                    mid_frame = int(round(start_frame + object_duration * 0.6))
                elif props.animation_velocity == 'DECELERATE':
                    mid_frame = int(round(start_frame + object_duration * 0.4))
                else:  # UNIFORM
                    mid_frame = int(round(start_frame + object_duration * 0.5))

                # Store mid-frame and animation index for use in animation methods/presets
                obj["mid_frame"] = mid_frame
                obj["animation_index"] = i

                # Apply collision detection if enabled and there are already animated objects
                if props.use_collision_detection and animated_objects:
                    other_objs = [o for o in objects if o != obj]
                    original_loc = obj.location.copy()
                    safe_pos = get_safe_position(obj, obj.location, other_objs, props.collision_margin)
                    if (safe_pos - original_loc).length > 1e-6:
                        obj.location = safe_pos

                self.create_object_animation(obj, props, start_frame, end_frame)
                animated_objects.append(obj)
            
            # Update timeline
            context.scene.frame_current = props.animation_start_frame
            
            # Update UI
            for area in context.screen.areas:
                if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                    area.tag_redraw()
            
            self.report({'INFO'}, "Animation created successfully")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error creating animation: {str(e)}")
            return {'CANCELLED'}

    def calculate_delays(self, props, object_count):
        """
        Calculate per-object delays for orchestral animation timing.
        Uses musicality for overlap and expressive sequencing.
        Returns a list of integer frame delays.
        """
        delays = [0] * object_count

        if props.delay_mode == 'NONE':
            return delays

        elif props.delay_mode == 'SEQUENTIAL':
            for i in range(object_count):
                delays[i] = int(round(i * props.delay_amount))

        elif props.delay_mode == 'OVERLAP':
            # Use musicality to control overlap (higher = more overlap)
            overlap = max(0.0, min(props.musicality, 1.0))
            overlap_factor = props.delay_amount * (1.0 - overlap)
            for i in range(object_count):
                delays[i] = int(round(i * overlap_factor))

        elif props.delay_mode == 'RANDOM':
            random.seed(props.random_seed)
            max_delay = props.delay_amount * object_count * max(0.1, props.musicality)
            for i in range(object_count):
                delays[i] = int(round(random.uniform(0, max_delay)))

        return delays

    def create_scale_animation(self, obj, props, start_frame, end_frame):
        """Create scale animation"""
        # Store original scale
        original_scale = obj.scale.copy()
        
        # Set initial scale (can be 0 or a very small value)
        initial_scale = 0.001  # Using small value instead of 0 to avoid object disappearing
        obj.scale = Vector((initial_scale, initial_scale, initial_scale))
        obj.keyframe_insert(data_path="scale", frame=start_frame)
        
        # Calculate final scale
        if obj.type == 'CURVE':
            # For curves, use the scale_final property
            final_scale = Vector(props.scale_final)
        else:
            # For other objects, maintain proportions
            final_scale = original_scale
        
        # Set final scale
        obj.scale = final_scale
        obj.keyframe_insert(data_path="scale", frame=end_frame)
        
        # Apply easing
        if obj.animation_data and obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                if fcurve.data_path == "scale":
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = props.preset_animation_interpolation
                        keyframe.easing = props.preset_animation_easing

        return True


    def create_rotate_animation(self, obj, props, start_frame, end_frame):
        """Create rotation animation"""
        # Store initial rotation
        initial_rotation = obj.rotation_euler.copy()
        obj.keyframe_insert(data_path="rotation_euler", frame=start_frame)
        
        # Calculate final rotation
        final_rotation = initial_rotation.copy()
        angle = props.rotation_angle
        if props.rotation_direction == 'CCW':
            angle = -angle
            
        if props.rotation_axis == 'X':
            final_rotation.x += angle
        elif props.rotation_axis == 'Y':
            final_rotation.y += angle
        else:  # Z axis
            final_rotation.z += angle
        
        # Set final rotation
        obj.rotation_euler = final_rotation
        obj.keyframe_insert(data_path="rotation_euler", frame=end_frame)
        
        # Apply animation easing
        if obj.animation_data and obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                if fcurve.data_path == "rotation_euler":
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = props.preset_animation_interpolation
                        keyframe.easing = props.preset_animation_easing
        
        return True


    def create_location_animation(self, obj, props, start_frame, end_frame):
        """Create location animation"""
        # Store original location
        original_loc = obj.location.copy()
        
        # Calculate start and end positions
        if props.use_relative_location:
            # Relative movement: add offset to original position
            start_pos = original_loc + Vector(props.location_start)
            end_pos = original_loc + Vector(props.location_end)
        else:
            # Absolute movement: use direct positions
            start_pos = Vector(props.location_start)
            end_pos = Vector(props.location_end)
        
        # Set and keyframe start position
        obj.location = start_pos
        obj.keyframe_insert(data_path="location", frame=start_frame)
        
        # Set and keyframe end position
        obj.location = end_pos
        obj.keyframe_insert(data_path="location", frame=end_frame)
        
        # Apply easing
        if obj.animation_data and obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                if fcurve.data_path == "location":
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = props.preset_animation_interpolation
                        keyframe.easing = props.preset_animation_easing
    
        return True                   
        
    def create_extrude_animation(self, obj, props, start_frame, end_frame):
        """Create extrude animation"""
        if obj.type == 'CURVE':
            # Set initial extrude
            obj.data.extrude = props.extrude_start
            obj.data.keyframe_insert(data_path="extrude", frame=start_frame)
            
            # Set final extrude
            obj.data.extrude = props.extrude_end
            obj.data.keyframe_insert(data_path="extrude", frame=end_frame)
            
            # Apply easing
            if obj.data.animation_data and obj.data.animation_data.action:
                for fcurve in obj.data.animation_data.action.fcurves:
                    if fcurve.data_path == "extrude":
                        for keyframe in fcurve.keyframe_points:
                            keyframe.interpolation = props.preset_animation_interpolation
                            keyframe.easing = props.preset_animation_easing
        return True

    def create_object_animation(self, obj, props, start_frame, end_frame):
        # Clear existing animation
        obj.animation_data_clear()
        obj.animation_data_create()
        
        # Create animations based on enabled toggles with offsets
        animations_created = False
        
        if props.use_scale:
            scale_start = start_frame + props.scale_offset
            scale_end = end_frame + props.scale_offset
            self.create_scale_animation(obj, props, scale_start, scale_end)
            animations_created = True
        
        if props.use_rotation:
            rotation_start = start_frame + props.rotation_offset
            rotation_end = end_frame + props.rotation_offset
            self.create_rotate_animation(obj, props, rotation_start, rotation_end)
            animations_created = True
        
        if props.use_location:
            location_start = start_frame + props.location_offset
            location_end = end_frame + props.location_offset
            self.create_location_animation(obj, props, location_start, location_end)
            animations_created = True
        
        if props.use_extrude and obj.type == 'CURVE':
            extrude_start = start_frame + props.extrude_offset
            extrude_end = end_frame + props.extrude_offset
            self.create_extrude_animation(obj, props, extrude_start, extrude_end)
            animations_created = True
        
        # If no animations were selected, create default scale animation
        if not animations_created:
            self.create_scale_animation(obj, props, start_frame, end_frame)

        return {'FINISHED'}             

class VECTART_OT_PresetAnimation(bpy.types.Operator):
    """Preset animation operator"""
    bl_idname = "vectart.preset_animation"
    bl_label = "Create Preset Animation"
    bl_description = "Create animation using predefined presets"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        if props.active_collection_index < 0:
            self.report({'WARNING'}, "No collection selected")
            return {'CANCELLED'}
            
        collection_item = props.collections[props.active_collection_index]
        if not collection_item.collection:
            self.report({'WARNING'}, "Invalid collection")
            return {'CANCELLED'}
            
        valid_objects = [obj for obj in collection_item.collection.objects if obj.type in {'MESH', 'CURVE'}]
        # Apply sorting based on layer order
        if props.layer_animation_order == 'TOP_DOWN':
            objects = sorted(valid_objects, key=lambda obj: obj.location.z, reverse=True)
        elif props.layer_animation_order == 'BOTTOM_UP':
            objects = sorted(valid_objects, key=lambda obj: obj.location.z)
        else:
            objects = valid_objects

        if not objects:
            self.report({'WARNING'}, "No objects in collection")
            return {'CANCELLED'}

        # Initialize list for animated objects (for collision detection)
        animated_objects = []
        
        try:
            for i, obj in enumerate(objects):
                obj["animation_index"] = i
                current_delay = calculate_sequence_timing(props, i, len(objects))
                obj_start = props.animation_start_frame + int(current_delay)

                # Collision detection fix
                if props.use_collision_detection:
                    other_objs = [o for o in objects if o != obj]
                    original_loc = obj.location.copy()
                    safe_pos = get_safe_position(obj, obj.location, other_objs, props.collision_margin)
                    if (safe_pos - original_loc).length > 1e-6:
                        obj.location = safe_pos

                try:
                    apply_preset_animation(self, context, obj, obj_start, props.animation_preset)
                    animated_objects.append(obj)
                except Exception as e:
                    self.report({'WARNING'}, f"Error applying preset to {obj.name}: {str(e)}")
                    return {'CANCELLED'}

            # Update timeline
            context.scene.frame_current = props.animation_start_frame
            
            # Update UI
            for area in context.screen.areas:
                if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                    area.tag_redraw()
                    
            self.report({'INFO'}, "Preset animation created successfully")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Animation creation failed: {str(e)}")
            return {'CANCELLED'}

class VECTART_OT_ApplyPreset(Operator):
    bl_idname = "vectart.apply_preset"
    bl_label = "Apply Preset"
    bl_description = "Apply the selected animation preset to selected objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects and len(context.selected_objects) > 0
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        if len(props.presets) == 0 or props.active_preset_index < 0:
            self.report({'WARNING'}, "No preset selected")
            return {'CANCELLED'}
            
        preset_id = props.presets[props.active_preset_index].preset_id

        # update random_seed for randomness each time ---
        if props.delay_mode == 'RANDOM':
            props.random_seed = int(time.time())

        # Calculate delays for all selected objects
        delays = VECTART_OT_DefaultAnimation.calculate_delays(self, props, len(context.selected_objects))
        
        # Apply preset to all selected objects with correct delays
        for i, obj in enumerate(context.selected_objects):
            start_frame = props.animation_start_frame + delays[i]
            apply_preset_animation(self, context, obj, start_frame, preset_id)
            
        self.report({'INFO'}, f"Applied preset to {len(context.selected_objects)} objects")
        return {'FINISHED'}


class VECTART_OT_RefreshPresets(Operator):
    bl_idname = "vectart.refresh_presets"
    bl_label = "Refresh Presets"
    bl_description = "Refresh animation presets list"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        
        # Clear existing presets
        props.presets.clear()
        
        # Preset data
        preset_data = [
            ("ROBOTIC_UNFOLD", "Robotic Unfold", "MESH_CUBE", "Robotic unfolding animation"),
            ("ROBOTIC_TRANSFORM", "Robotic Transform", "MESH_CYLINDER", "Complex transformation sequence"),
            ("TECH_ASSEMBLY", "Tech Assembly", "MESH_GRID", "Technical assembly animation"),
            ("MECH_STARTUP", "Mech Startup", "MESH_MONKEY", "Mechanical startup sequence"),
            ('ORIGAMI', "Origami", "ORIENTATION_LOCAL", "Complex origami folding and unfolding animation"),
            ("HOLOGRAPHIC_APPEAR", "Holographic", "LIGHT_POINT", "Holographic appearance effect"),
            ("GLITCH_APPEAR", "Glitch", "MOD_NOISE", "Glitch appearance effect"),
            ("ASSEMBLE", "Assemble", "MOD_BUILD", "Parts assembly animation"),
            ("MAGNETIC", "Magnetic", "FORCE_MAGNETIC", "Magnetic attraction animation"),
            ("EXPLODE", "Explode", "MOD_EXPLODE", "Object explosion animation"),
        ]
        
        # Add presets
        for preset_id, name, icon, desc in preset_data:
            item = props.presets.add()
            item.name = name
            item.preset_id = preset_id
            item.icon = icon
            item.description = desc
            
        self.report({'INFO'}, f"Added {len(preset_data)} animation presets")
        return {'FINISHED'}

class VECTART_OT_CopyKeyframes(Operator):
    bl_idname = "vectart.copy_keyframes"
    bl_label = "Copy Keyframes"
    bl_description = "Copy keyframes from selected objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(obj.animation_data for obj in context.selected_objects)
    
    def execute(self, context):
        # Store keyframe data for all selected objects
        all_keyframe_data = {}
        
        for obj in context.selected_objects:
            if not obj.animation_data or not obj.animation_data.action:
                continue
                
            # Store keyframe data for this object
            keyframe_data = []
            for fcurve in obj.animation_data.action.fcurves:
                curve_data = {
                    'data_path': fcurve.data_path,
                    'array_index': fcurve.array_index,
                    'keyframes': []
                }
                for kf in fcurve.keyframe_points:
                    curve_data['keyframes'].append({
                        'co': kf.co[:],
                        'handle_left': kf.handle_left[:],
                        'handle_right': kf.handle_right[:],
                        'interpolation': kf.interpolation,
                        'easing': kf.easing
                    })
                keyframe_data.append(curve_data)
            
            # Store data for this object
            if keyframe_data:
                all_keyframe_data[obj.name] = keyframe_data
        
        if not all_keyframe_data:
            self.report({'WARNING'}, "No animation data to copy")
            return {'CANCELLED'}
            
        context.scene['vectart_copied_keyframes'] = all_keyframe_data
        self.report({'INFO'}, f"Keyframes copied from {len(all_keyframe_data)} objects")
        return {'FINISHED'}

class VECTART_OT_PasteKeyframesReverse(Operator):
    bl_idname = "vectart.paste_keyframes_reverse"
    bl_label = "Paste Keyframes Reversed"
    bl_description = "Paste copied keyframes in reverse order to selected objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return (context.selected_objects and 
                'vectart_copied_keyframes' in context.scene)
    
    def execute(self, context):
        props = context.scene.vectart_animation_props
        all_keyframe_data = context.scene['vectart_copied_keyframes']
        
        if not all_keyframe_data:
            self.report({'WARNING'}, "No keyframes to paste")
            return {'CANCELLED'}
        
        # Get all source object names
        source_names = list(all_keyframe_data.keys())
        
        # For each selected target object
        pasted_count = 0
        for obj in context.selected_objects:
            # Choose source data - either matching name or first available
            source_name = obj.name if obj.name in source_names else source_names[0]
            keyframe_data = all_keyframe_data[source_name]
            
            # Create new animation data if needed
            if not obj.animation_data:
                obj.animation_data_create()
            if not obj.animation_data.action:
                obj.animation_data.action = bpy.data.actions.new(name=f"{obj.name}_Action")
                
            # Calculate time range of source animation
            all_times = [kf['co'][0] for curve in keyframe_data for kf in curve['keyframes']]
            if not all_times:
                continue
                
            original_end = max(all_times)
            
            # Paste reversed keyframes
            for curve_data in keyframe_data:
                fcurve = obj.animation_data.action.fcurves.find(
                    curve_data['data_path'], 
                    index=curve_data['array_index']
                )
                if not fcurve:
                    fcurve = obj.animation_data.action.fcurves.new(
                        data_path=curve_data['data_path'],
                        index=curve_data['array_index']
                    )
                    
                # Reverse and offset keyframes
                for kf_data in reversed(curve_data['keyframes']):
                    original_time = kf_data['co'][0]
                    reversed_time = props.paste_target_frame + (original_end - original_time)
                    
                    keyframe = fcurve.keyframe_points.insert(
                        reversed_time,
                        kf_data['co'][1]
                    )
                    keyframe.interpolation = kf_data['interpolation']
                    if 'easing' in kf_data:
                        keyframe.easing = kf_data['easing']
            
            pasted_count += 1
                
        self.report({'INFO'}, f"Keyframes pasted in reverse order to {pasted_count} objects")
        return {'FINISHED'}

class VECTART_OT_InitializeObjects(bpy.types.Operator):
    bl_idname = "vectart.initialize_objects"
    bl_label = "Initialize Objects"
    bl_description = "Store original transform values for selected objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects
    
    def execute(self, context):
        initialized_count = 0
        
        for obj in context.selected_objects:
            # Store original transform values
            obj["original_location"] = [v for v in obj.location]
            obj["original_rotation"] = [v for v in obj.rotation_euler]
            obj["original_scale"] = [v for v in obj.scale]
            
            # Store curve-specific data
            if obj.type == 'CURVE':
                if hasattr(obj.data, "extrude"):
                    obj["original_extrude"] = obj.data.extrude
                if hasattr(obj.data, "bevel_depth"):
                    obj["original_bevel_depth"] = obj.data.bevel_depth
            
            initialized_count += 1
        
        self.report({'INFO'}, f"Stored original transforms for {initialized_count} objects")
        return {'FINISHED'}


class VECTART_OT_ClearAnimation(Operator):
    bl_idname = "vectart.clear_animation"
    bl_label = "Clear Animation"
    bl_description = "Clear animation and restore original state"
    bl_options = {'REGISTER', 'UNDO'}
    
    restore_location: BoolProperty(
        name="Restore Location",
        description="Restore original location",
        default=True
    )
    restore_rotation: BoolProperty(
        name="Restore Rotation",
        description="Restore original rotation",
        default=True
    )
    restore_scale: BoolProperty(
        name="Restore Scale",
        description="Restore original scale",
        default=True
    )
    restore_extrude: BoolProperty(
        name="Restore Extrude",
        description="Restore original extrude value for curves",
        default=True
    )
    clear_all: BoolProperty(
        name="Clear All Animation Data",
        description="Remove all animation data completely",
        default=False
    )
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(obj.animation_data for obj in context.selected_objects)
    
    def store_original_state(self, obj):
        """Store the original state of an object"""
        original_state = {
            'location': obj.location.copy(),
            'rotation_euler': obj.rotation_euler.copy(),
            'scale': obj.scale.copy()
        }
        
        # Store curve-specific data
        if obj.type == 'CURVE':
            if hasattr(obj.data, "extrude"):
                original_state['extrude'] = obj.data.extrude
            if hasattr(obj.data, "bevel_depth"):
                original_state['bevel_depth'] = obj.data.bevel_depth
            
        return original_state
    
    def restore_object_state(self, obj):
        """Restore object to its original state using stored values"""
        if self.restore_location and "original_location" in obj:
            obj.location = Vector(obj["original_location"])
        
        if self.restore_rotation and "original_rotation" in obj:
            obj.rotation_euler = Euler(obj["original_rotation"])
        
        if self.restore_scale and "original_scale" in obj:
            obj.scale = Vector(obj["original_scale"])
        
        if obj.type == 'CURVE':
            if self.restore_extrude and "original_extrude" in obj:
                obj.data.extrude = obj["original_extrude"]
            if "original_bevel_depth" in obj:
                obj.data.bevel_depth = obj["original_bevel_depth"]

    
    def clear_animation_data(self, obj):
        """Clear all animation data from an object"""
        # If clear_all is enabled, just clear everything
        if self.clear_all and obj.animation_data:
            obj.animation_data_clear()
            if obj.type == 'CURVE' and obj.data.animation_data:
                obj.data.animation_data_clear()
            return
            
        # Clear object animation
        if obj.animation_data and obj.animation_data.action:
            # Create a list of fcurves to remove
            fcurves_to_remove = []
            
            for fc in obj.animation_data.action.fcurves:
                if (self.restore_location and fc.data_path.startswith("location")) or \
                   (self.restore_rotation and fc.data_path.startswith("rotation")) or \
                   (self.restore_scale and fc.data_path.startswith("scale")):
                    fcurves_to_remove.append(fc)
            
            # Remove the fcurves
            for fc in fcurves_to_remove:
                obj.animation_data.action.fcurves.remove(fc)
                
            # If no fcurves left, clear all animation data
            if not obj.animation_data.action.fcurves:
                obj.animation_data_clear()
        
        # Clear curve data animation
        if obj.type == 'CURVE' and obj.data.animation_data and obj.data.animation_data.action:
            fcurves_to_remove = []
            
            for fc in obj.data.animation_data.action.fcurves:
                if (self.restore_extrude and fc.data_path.startswith("extrude")) or \
                   fc.data_path.startswith("bevel_depth"):
                    fcurves_to_remove.append(fc)
            
            for fc in fcurves_to_remove:
                obj.data.animation_data.action.fcurves.remove(fc)
                
            if not obj.data.animation_data.action.fcurves:
                obj.data.animation_data_clear()
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "clear_all")
        
        if not self.clear_all:
            box = layout.box()
            box.label(text="Restore Properties:")
            box.prop(self, "restore_location")
            box.prop(self, "restore_rotation")
            box.prop(self, "restore_scale")
            
            # Only show extrude option if any curves are selected
            if any(obj.type == 'CURVE' for obj in context.selected_objects):
                box.prop(self, "restore_extrude")
    
    def execute(self, context):
        cleared_count = 0
        for obj in context.selected_objects:
            if obj.animation_data:
                self.clear_animation_data(obj)
                
                # Restore original state from stored values
                self.restore_object_state(obj)
                cleared_count += 1

        context.view_layer.update()
        self.report({'INFO'}, f"Cleared animation for {cleared_count} objects")
        return {'FINISHED'}


# UI List
class VECTART_UL_CollectionList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            
            # Collection visibility toggle
            icon = 'COLLECTION_COLOR_05' if item.active else 'STRIP_COLOR_01'
            row.prop(item, "active", text="", icon=icon, emboss=False)
            
            # Collection name
            row.prop(item, "name", text="", emboss=False)
            
            # Show number of objects in collection
            if item.collection:
                row.label(text=f"({len(item.collection.objects)})")

class VECTART_UL_PresetList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "name", text="", emboss=False, icon=item.icon if item.icon != "NONE" else 'NONE')


# Panels
class VECTART_PT_AnimationMainPanel(bpy.types.Panel):
    """Main Animation Panel"""
    bl_label = "VectArt Animation"
    bl_idname = "VECTART_PT_animation_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        # Collection Management
        box = layout.box()
        box.label(text="Collections", icon='MOD_BUILD')
        
        row = box.row()
        row.template_list("VECTART_UL_CollectionList", "", props, "collections",
                            props, "active_collection_index", rows=3)
        
        col = row.column(align=True)
        col.operator("vectart.add_collection", text="", icon='ADD')
        col.operator("vectart.remove_collection", text="", icon='REMOVE')
        col.operator("vectart.clear_collections", text="", icon='X')
        col.operator("vectart.refresh_collections", text="", icon='FILE_REFRESH')

        box = layout.box()
        box.label(text="Timing Settings", icon='TIME')

        grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        grid.prop(props, "animation_start_frame")
        grid.prop(props, "auto_duration")
        grid.prop(props, "delay_mode")
        grid.prop(props, "musicality", slider=True)

        if props.auto_duration:
            grid.prop(props, "frames_per_object")
            obj_count = 0
            if len(props.collections) > 0 and props.active_collection_index >= 0 and props.active_collection_index < len(props.collections):
                collection_item = props.collections[props.active_collection_index]
                if collection_item.collection:
                    obj_count = len([obj for obj in collection_item.collection.objects if obj.type in {'MESH', 'CURVE'}])
            if obj_count > 0:
                total_frames = obj_count * props.frames_per_object
                grid.label(text=f"Total: {total_frames} frames")
        else:
            grid.prop(props, "duration")

        box = layout.box()
        box.label(text="Delay Properties", icon='OPTIONS')
        col = box.column(align=True)
        if props.delay_mode != 'NONE':
            col.prop(props, "delay_amount")
            if props.delay_mode == 'RANDOM':
                col.prop(props, "random_seed")
            elif props.delay_mode == 'OVERLAP':
                col.prop(props, "overlap_div")


class VECTART_PT_AnimationStylePanel(bpy.types.Panel):
    """Animation Style Panel"""
    bl_label = "Style Settings"
    bl_idname = "VECTART_PT_animation_style"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_animation_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props
        
        col = layout.column(align=True)
        col.prop(props, "animation_mode")
        
        if props.animation_mode == 'DEFAULT':
            # Animation combination toggles
            box = layout.box()
            box.label(text="Animation Types")
            
            # Create a grid layout for animation types and their offsets
            grid = box.grid_flow(row_major=True, columns=2, even_columns=True)
            
            # Scale
            col = grid.column()
            row = col.row()
            row.prop(props, "use_scale", text="Scale", toggle=True)
            if props.use_scale:
                row.prop(props, "scale_offset", text="Offset")
            
            # Rotation
            col = grid.column()
            row = col.row()
            row.prop(props, "use_rotation", text="Rotation", toggle=True)
            if props.use_rotation:
                row.prop(props, "rotation_offset", text="Offset")
            
            # Location
            col = grid.column()
            row = col.row()
            row.prop(props, "use_location", text="Location", toggle=True)
            if props.use_location:
                row.prop(props, "location_offset", text="Offset")
            
            # Extrude (only for curves)
            if any(obj.type == 'CURVE' for obj in context.selected_objects):
                col = grid.column()
                row = col.row()
                row.prop(props, "use_extrude", text="Extrude", toggle=True)
                if props.use_extrude:
                    row.prop(props, "extrude_offset", text="Offset")
            
            # Show settings for enabled animation types
            if props.use_scale:
                box = layout.box()
                box.label(text="Scale Settings")
                split = box.split()
                left_col = split.column()
                left_col.prop(props, "scale_min")
                right_col = split.column()
                right_col.prop(props, "scale_final")
                box.prop(props, "maintain_proportions")
                
            if props.use_rotation:
                box = layout.box()
                box.label(text="Rotation Settings")
                col = box.column(align=True)
                col.prop(props, "rotation_axis")
                col.prop(props, "rotation_angle")
                col.prop(props, "rotation_direction")
                
            if props.use_location:
                box = layout.box()
                box.label(text="Location Settings")
                split = box.split()
                left_col = split.column()
                left_col.label(text="Start Offset:" if props.use_relative_location else "Start Position:")
                left_col.prop(props, "location_start", text="")
                right_col = split.column()
                right_col.label(text="End Offset:" if props.use_relative_location else "End Position:")
                right_col.prop(props, "location_end", text="")
                box.prop(props, "use_relative_location")
                
            if props.use_extrude and any(obj.type == 'CURVE' for obj in context.selected_objects):
                box = layout.box()
                box.label(text="Extrude Settings")
                col = box.column(align=True)
                col.prop(props, "extrude_start")
                col.prop(props, "extrude_end")
                col.prop(props, "extrude_steps")
        
        elif props.animation_mode == 'PRESET':
            # Add refresh button
            row = layout.row(align=True)
            row.operator("vectart.refresh_presets", icon='FILE_REFRESH', text="Refresh Presets")
            # Draw preset list
            row = layout.row()
            row.template_list("VECTART_UL_PresetList", "", props, "presets", 
                             props, "active_preset_index", rows=3)
            
            # Show description of selected preset
            if len(props.presets) > 0 and props.active_preset_index >= 0:
                preset = props.presets[props.active_preset_index]
                layout.label(text=preset.description)
            
            
            box = layout.box()
            box.label(text="Collision Settings")
            box.prop(props, "use_collision_detection")
            if props.use_collision_detection:
                box.prop(props, "collision_margin")
    

class VECTART_PT_AnimationAdvancedPanel(bpy.types.Panel):
    """Advanced Animation Settings Panel"""
    bl_label = "Advanced Settings"
    bl_idname = "VECTART_PT_animation_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_animation_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        # Interpolation Settings
        box = layout.box()
        box.label(text="Interpolation / Animation Flow")
        split = box.split()
        left_col = split.column()
        left_col.prop(props, "preset_animation_interpolation")
        left_col.prop(props, "preset_animation_easing")
        
       
        
        # Animation Flow
        right_col = split.column()
        right_col.prop(props, "animation_velocity")
       
       
        right_col.prop(props, "layer_animation_order")
        box.prop(props, "use_local_axis")

class VECTART_PT_AnimationToolsPanel(bpy.types.Panel):
    """ Animation Tools Settings Panel"""
    bl_label = "Tools Settings"
   
    bl_idname = "VECTART_PT_animation_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_animation_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props 

        box = layout.box()
        box.label(text="Quick Select", icon='RESTRICT_SELECT_OFF')
        row = box.row(align=True)
        row.operator("vectart.select_collection_objects", text="All").select_type = 'ALL'
        row.operator("vectart.select_collection_objects", text="Curves").select_type = 'CURVES'
        row.operator("vectart.select_collection_objects", text="Meshes").select_type = 'MESHES'

        box = layout.box()
        box.label(text="Object Management", icon='OBJECT_DATA')

        row = box.row(align=True)
        row.operator("vectart.initialize_objects", icon='IMPORT')

        # Keyframe Tools
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "paste_target_frame")

        box.label(text="Keyframe Tools", icon='ACTION')
        row = box.row(align=True)
        row.operator("vectart.copy_keyframes", icon='COPYDOWN')
        row.operator("vectart.paste_keyframes_reverse", icon='PASTEDOWN')

        row = layout.row(align=True)
        row.scale_y = 3.0

        if props.animation_mode == 'DEFAULT':
            row.operator("vectart.default_animation", icon='PLAY', text="Create Animation")
        elif props.animation_mode == 'PRESET':
            row.operator("vectart.apply_preset", icon='CHECKMARK', text="Apply Preset")
        
        row.operator("vectart.clear_animation", icon='CANCEL', text="Clear Animation")
    
    
# Registration
classes = [
    PresetItem,
    VectartCollectionItem,
    VectartAnimationProperties,
    VECTART_OT_AddCollection,
    VECTART_OT_RemoveCollection,
    VECTART_OT_ClearCollections,
    VECTART_OT_RefreshCollections,
    VECTART_OT_SelectCollectionObjects,
    VECTART_OT_DefaultAnimation,
    VECTART_OT_PresetAnimation,
    VECTART_OT_CopyKeyframes,
    VECTART_OT_PasteKeyframesReverse,
    VECTART_OT_InitializeObjects,
    VECTART_OT_ClearAnimation,
    VECTART_OT_ApplyPreset,
    VECTART_OT_RefreshPresets,
    VECTART_UL_PresetList,

    # UIList
    VECTART_UL_CollectionList,

    # Panels
    VECTART_PT_AnimationMainPanel,
    VECTART_PT_AnimationStylePanel,
    VECTART_PT_AnimationAdvancedPanel,
       VECTART_PT_AnimationToolsPanel,
]

def register():
    # Register classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print(f"Error registering {cls.__name__}: {str(e)}")
    
    bpy.types.Scene.vectart_animation_props = PointerProperty(type=VectartAnimationProperties)
    bpy.types.Scene.vectart_collections = CollectionProperty(type=VectartCollectionItem)
    

def unregister():
    del bpy.types.Scene.vectart_collections
    del bpy.types.Scene.vectart_animation_props
    
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"Error unregistering {cls.__name__}: {str(e)}")

if __name__ == "__main__":
    register()
