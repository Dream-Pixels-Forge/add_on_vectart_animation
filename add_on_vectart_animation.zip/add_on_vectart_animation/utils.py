# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""Utility functions for collision detection, timing, and preset animation logic."""

from __future__ import annotations

import math
import random
from typing import TYPE_CHECKING

from mathutils import Vector, Euler

if TYPE_CHECKING:
    import bpy


# -----------------------------------------------------------------------------
# Bounding-Box / Collision Helpers
# -----------------------------------------------------------------------------

def get_bounding_box_dimensions(obj) -> tuple[Vector, Vector]:
    """Return (dimensions, center) of an object's world-space bounding box."""
    bbox_vertices = [Vector(v) @ obj.matrix_world for v in obj.bound_box]

    min_x = min(v.x for v in bbox_vertices)
    max_x = max(v.x for v in bbox_vertices)
    min_y = min(v.y for v in bbox_vertices)
    max_y = max(v.y for v in bbox_vertices)
    min_z = min(v.z for v in bbox_vertices)
    max_z = max(v.z for v in bbox_vertices)

    dimensions = Vector((max_x - min_x, max_y - min_y, max_z - min_z))
    center = Vector(((max_x + min_x) / 2, (max_y + min_y) / 2, (max_z + min_z) / 2))
    return dimensions, center


def check_collision(obj1, obj2, margin: float = 0.1, epsilon: float = 1e-5) -> bool:
    """Check if two objects' bounding boxes overlap (with margin)."""
    dims1, center1 = get_bounding_box_dimensions(obj1)
    dims2, center2 = get_bounding_box_dimensions(obj2)

    dims1 = dims1 * (1 + margin)
    dims2 = dims2 * (1 + margin)

    distance_vector = center1 - center2

    return (
        abs(distance_vector.x) * 2 < (dims1.x + dims2.x + epsilon)
        and abs(distance_vector.y) * 2 < (dims1.y + dims2.y + epsilon)
        and abs(distance_vector.z) * 2 < (dims1.z + dims2.z + epsilon)
    )


def get_safe_position(
    obj,
    target_pos: Vector,
    other_objects: list,
    margin: float = 0.1,
    max_attempts: int = 100,
) -> Vector:
    """Find a position for *obj* near *target_pos* that avoids collisions."""
    if not other_objects:
        return target_pos

    dims, _ = get_bounding_box_dimensions(obj)
    orig_pos = obj.location.copy()

    # 26 directions (axis-aligned + diagonals)
    directions = [
        Vector((x, y, z))
        for x in (-1, 0, 1)
        for y in (-1, 0, 1)
        for z in (-1, 0, 1)
        if (x, y, z) != (0, 0, 0)
    ]

    base_distance = max(dims) * (1 + margin)
    distances = [base_distance * (i + 1) for i in range(6)]

    attempt = 0
    for distance in distances:
        for direction in directions:
            test_pos = target_pos + direction.normalized() * distance
            obj.location = test_pos
            if not any(
                other != obj and check_collision(obj, other, margin)
                for other in other_objects
            ):
                obj.location = orig_pos
                return test_pos
            attempt += 1
            if attempt > max_attempts:
                break
        if attempt > max_attempts:
            break

    # Random jitter fallback
    for _ in range(20):
        jitter = Vector((
            random.uniform(-1, 1),
            random.uniform(-1, 1),
            random.uniform(-1, 1),
        )) * base_distance * 2
        test_pos = target_pos + jitter
        obj.location = test_pos
        if not any(
            other != obj and check_collision(obj, other, margin)
            for other in other_objects
        ):
            obj.location = orig_pos
            return test_pos

    # Axis-shift fallback
    axis = max(range(3), key=lambda i: dims[i])
    for sign in (-1, 1):
        test_pos = target_pos.copy()
        test_pos[axis] += sign * base_distance * 4
        obj.location = test_pos
        if not any(
            other != obj and check_collision(obj, other, margin)
            for other in other_objects
        ):
            obj.location = orig_pos
            return test_pos

    # Recursive increase margin (limited)
    if margin < 0.5:
        obj.location = orig_pos
        return get_safe_position(obj, target_pos, other_objects, margin + 0.1, max_attempts)

    obj.location = orig_pos
    return target_pos


# -----------------------------------------------------------------------------
# Timing Helpers
# -----------------------------------------------------------------------------

def calculate_sequence_timing(props, index: int, total_elements: int, action_index: int = 0) -> int:
    """Calculate start-frame offset for a given object/action in the sequence."""
    base_duration = props.frames_per_object

    if props.delay_mode == 'NONE':
        element_delay = 0
    elif props.delay_mode == 'SEQUENTIAL':
        element_delay = props.delay_amount
    elif props.delay_mode == 'RANDOM':
        random.seed(props.random_seed + index + action_index * 1000)
        element_delay = random.uniform(0, props.delay_amount)
    elif props.delay_mode == 'OVERLAP':
        overlap = max(0.0, min(props.overlap_div, 1.0))
        element_delay = base_duration * (1 - overlap)
    else:
        element_delay = 0

    element_start = index * (base_duration + element_delay)
    musicality = props.musicality
    action_offset = action_index * (total_elements * (base_duration + element_delay) * musicality)

    return int(round(action_offset + element_start))


# -----------------------------------------------------------------------------
# Preset Sequence Builders
# -----------------------------------------------------------------------------

def _random_mech_angle() -> float:
    """Random choice of +/-90, +/-180, +/-360 degrees in radians."""
    return math.radians(random.choice([90, -90, 180, -180, 360, -360]))


def _random_origami_axis() -> tuple[int, int, int]:
    axes = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 0, 0), (0, -1, 0), (0, 0, -1)]
    return random.choice(axes)


def _random_origami_angle() -> float:
    return math.radians(random.choice([90, -90, 180, -180]))


def build_origami_sequence(orig_scale: Vector, orig_rot, orig_loc: Vector, steps: int = 4) -> list:
    """Build a complex origami fold/unfold sequence."""
    seq: list = []
    scale = orig_scale.copy()
    rot = orig_rot.copy()

    for _ in range(steps):
        axis = _random_origami_axis()
        angle = _random_origami_angle()
        fold_scale = Vector([scale[j] * (0.2 if axis[j] != 0 else 1.0) for j in range(3)])
        fold_rot = rot.copy()
        for j in range(3):
            if axis[j] != 0:
                fold_rot[j] += angle
        seq.append(('SCALE', scale.copy(), fold_scale.copy()))
        seq.append(('ROTATION', rot.copy(), fold_rot.copy()))
        scale = fold_scale
        rot = fold_rot

    # Unfold
    for _ in range(steps):
        axis = _random_origami_axis()
        angle = _random_origami_angle()
        unfold_scale = Vector([orig_scale[j] if axis[j] != 0 else scale[j] for j in range(3)])
        unfold_rot = rot.copy()
        for j in range(3):
            if axis[j] != 0:
                unfold_rot[j] -= angle
        seq.append(('SCALE', scale.copy(), unfold_scale.copy()))
        seq.append(('ROTATION', rot.copy(), unfold_rot.copy()))
        scale = unfold_scale
        rot = unfold_rot

    # Final restore
    seq.append(('SCALE', scale.copy(), orig_scale.copy()))
    seq.append(('ROTATION', rot.copy(), orig_rot.copy()))
    seq.append(('LOCATION', orig_loc.copy(), orig_loc.copy()))
    return seq


def get_preset_sequence(preset_type: str, obj, props) -> list | None:
    """Return the animation sequence list for a given preset type."""
    orig_loc = obj.location.copy()
    orig_rot = obj.rotation_euler.copy()
    orig_scale = obj.scale.copy()

    preset_sequences = {
        'ROBOTIC_UNFOLD': [
            ('SCALE', Vector((0, 0, 0)), Vector((0.1, 0.1, 0.1))),
            ('SCALE', Vector((0.1, 0.1, 0.1)), Vector((0.4, 0.4, 0.4))),
            ('LOCATION', Vector((random.uniform(-4, 4), random.uniform(-4, 4), random.uniform(-2, 2))), obj.location.copy()),
            ('ROTATION', Vector((0, 0, 0)), Vector((_random_mech_angle(), _random_mech_angle(), 0))),
            ('SCALE', Vector((0.4, 0.4, 0.4)), Vector((1.15, 1.15, 1.15))),
            ('ROTATION', Vector((_random_mech_angle(), 0, 0)), Vector((orig_rot.x * 0.5, orig_rot.y, orig_rot.z))),
            ('SCALE', Vector((1.15, 1.15, 1.15)), orig_scale),
            ('ROTATION', Vector((orig_rot.x * 0.5, orig_rot.y, orig_rot.z)), orig_rot),
            ('LOCATION', obj.location.copy(), orig_loc),
        ],
        'ROBOTIC_TRANSFORM': [
            ('LOCATION', Vector((random.uniform(-6, 6), random.uniform(-6, 6), random.uniform(2, 6))), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 1))),
            ('SCALE', Vector((0.05, 0.05, 0.05)), Vector((0.8, 0.8, 0.8))),
            ('ROTATION', Vector((0, 0, 0)), Vector((_random_mech_angle(), _random_mech_angle(), _random_mech_angle()))),
            ('SCALE', Vector((0.8, 0.8, 0.8)), Vector((1.3, 1.3, 1.3))),
            ('ROTATION', Vector((_random_mech_angle(), _random_mech_angle(), 0)), Vector((orig_rot.x, orig_rot.y, _random_mech_angle()))),
            ('SCALE', Vector((1.3, 1.3, 1.3)), orig_scale),
            ('ROTATION', Vector((orig_rot.x, orig_rot.y, _random_mech_angle())), orig_rot),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 1)), orig_loc),
        ],
        'TECH_ASSEMBLY': [
            ('SCALE', Vector((0, 0, 0)), Vector((0.3, 0.3, 0.3))),
            ('LOCATION', Vector((random.uniform(-8, 8), random.uniform(-8, 8), random.uniform(4, 8))), Vector((orig_loc.x + random.uniform(-1, 1), orig_loc.y, orig_loc.z + 2))),
            ('ROTATION', Vector((_random_mech_angle(), 0, 0)), Vector((0, _random_mech_angle(), 0))),
            ('SCALE', Vector((0.3, 0.3, 0.3)), Vector((0.9, 0.9, 0.9))),
            ('LOCATION', Vector((orig_loc.x + random.uniform(-1, 1), orig_loc.y, orig_loc.z + 2)), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.5))),
            ('SCALE', Vector((0.9, 0.9, 0.9)), orig_scale),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.5)), orig_loc),
            ('ROTATION', Vector((0, _random_mech_angle(), 0)), orig_rot),
        ],
        'MECH_STARTUP': [
            ('SCALE', Vector((0.02, 0.02, 0.02)), Vector((0.5, 0.5, 0.5))),
            ('ROTATION', Vector((0, 0, 0)), Vector((0, _random_mech_angle(), 0))),
            ('SCALE', Vector((0.5, 0.5, 0.5)), Vector((1.15, 1.15, 1.15))),
            ('SCALE', Vector((1.15, 1.15, 1.15)), Vector((0.92, 0.92, 0.92))),
            ('SCALE', Vector((0.92, 0.92, 0.92)), Vector((1.05, 1.05, 1.05))),
            ('SCALE', Vector((1.05, 1.05, 1.05)), orig_scale),
            ('LOCATION', obj.location.copy(), orig_loc),
            ('ROTATION', obj.rotation_euler.copy(), orig_rot),
        ],
        'ORIGAMI': build_origami_sequence(orig_scale, orig_rot, orig_loc, steps=4),
        'HOLOGRAPHIC_APPEAR': [
            ('SCALE', Vector((1.0, 1.0, 0.01)), Vector((1.0, 1.0, 0.3))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 6)), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 3))),
            ('SCALE', Vector((1.0, 1.0, 0.3)), Vector((0.8, 0.8, 0.8))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 3)), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.5))),
            ('SCALE', Vector((0.8, 0.8, 0.8)), Vector((1.05, 1.05, 1.05))),
            ('SCALE', Vector((1.05, 1.05, 1.05)), orig_scale),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.5)), orig_loc),
            ('ROTATION', Vector((0, 0, math.radians(5))), orig_rot),
        ],
        'GLITCH_APPEAR': [
            ('SCALE', Vector((0, 0, 0)), Vector((random.uniform(0.3, 0.7), random.uniform(0.3, 0.7), random.uniform(0.3, 0.7)))),
            ('LOCATION', Vector((random.uniform(-3, 3), random.uniform(-3, 3), random.uniform(-3, 3))), Vector((random.uniform(-1, 1), random.uniform(-1, 1), 0))),
            ('SCALE', Vector((random.uniform(0.3, 0.7), random.uniform(0.3, 0.7), random.uniform(0.3, 0.7))), Vector((1.4, 1.4, 1.4))),
            ('LOCATION', Vector((random.uniform(-1, 1), random.uniform(-1, 1), 0)), Vector((random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5), 0))),
            ('SCALE', Vector((1.4, 1.4, 1.4)), Vector((0.8, 0.8, 0.8))),
            ('SCALE', Vector((0.8, 0.8, 0.8)), orig_scale),
            ('LOCATION', Vector((random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5), 0)), orig_loc),
            ('ROTATION', Vector((random.uniform(-math.pi, math.pi), random.uniform(-0.3, 0.3), 0)), orig_rot),
        ],
        'ASSEMBLE': [
            ('SCALE', Vector((random.uniform(0.05, 0.2), random.uniform(0.05, 0.2), random.uniform(0.05, 0.2))), Vector((0.6, 0.6, 0.6))),
            ('LOCATION', Vector((random.uniform(-12, 12), random.uniform(-12, 12), random.uniform(6, 18))), Vector((orig_loc.x + random.uniform(-1, 1), orig_loc.y + random.uniform(-1, 1), orig_loc.z + 2))),
            ('ROTATION', Vector((random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi))), Vector((orig_rot.x + random.uniform(-0.3, 0.3), orig_rot.y, orig_rot.z))),
            ('SCALE', Vector((0.6, 0.6, 0.6)), Vector((1.1, 1.1, 1.1))),
            ('LOCATION', Vector((orig_loc.x + random.uniform(-1, 1), orig_loc.y + random.uniform(-1, 1), orig_loc.z + 2)), orig_loc),
            ('SCALE', Vector((1.1, 1.1, 1.1)), orig_scale),
            ('ROTATION', Vector((orig_rot.x + random.uniform(-0.3, 0.3), orig_rot.y, orig_rot.z)), orig_rot),
        ],
        'MAGNETIC': [
            ('LOCATION', Vector((random.uniform(-15, 15), random.uniform(-15, 15), random.uniform(-15, 15))), Vector((orig_loc.x + random.uniform(-2, 2), orig_loc.y + random.uniform(-2, 2), orig_loc.z + 3))),
            ('SCALE', Vector((0.6, 0.6, 0.6)), Vector((0.9, 0.9, 0.9))),
            ('LOCATION', Vector((orig_loc.x + random.uniform(-2, 2), orig_loc.y + random.uniform(-2, 2), orig_loc.z + 3)), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.8))),
            ('SCALE', Vector((0.9, 0.9, 0.9)), Vector((1.15, 1.15, 1.15))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.8)), orig_loc),
            ('SCALE', Vector((1.15, 1.15, 1.15)), orig_scale),
            ('ROTATION', Vector((random.uniform(-math.pi / 4, math.pi / 4), random.uniform(-math.pi / 4, math.pi / 4), random.uniform(-math.pi / 4, math.pi / 4))), orig_rot),
        ],
        'EXPLODE': [
            ('SCALE', orig_scale, Vector((1.3, 1.3, 1.3))),
            ('SCALE', Vector((1.3, 1.3, 1.3)), Vector((1.6, 1.6, 1.6))),
            ('LOCATION', orig_loc, Vector((orig_loc.x + random.uniform(-10, 10), orig_loc.y + random.uniform(-10, 10), orig_loc.z + random.uniform(2, 10)))),
            ('ROTATION', orig_rot, Vector((random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi), random.uniform(-math.pi, math.pi)))),
            ('SCALE', Vector((1.6, 1.6, 1.6)), Vector((0.3, 0.3, 0.3))),
            ('SCALE', Vector((0.3, 0.3, 0.3)), Vector((0.01, 0.01, 0.01))),
        ],
        # --- NEW PRESETS ---
        'TYPEWRITER': [
            ('SCALE', Vector((0, 0, 0)), Vector((0, 0, 0))),
            ('SCALE', Vector((0, 0, 0)), Vector((1.3, 1.3, 1.3))),
            ('SCALE', Vector((1.3, 1.3, 1.3)), orig_scale),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 0.5)), orig_loc),
        ],
        'SPIRAL_IN': [
            ('SCALE', Vector((0, 0, 0)), Vector((0.3, 0.3, 0.3))),
            ('LOCATION', Vector((orig_loc.x + random.uniform(3, 6) * random.choice([-1, 1]), orig_loc.y + random.uniform(3, 6) * random.choice([-1, 1]), orig_loc.z + random.uniform(2, 5))), Vector((orig_loc.x + 1, orig_loc.y + 1, orig_loc.z + 1))),
            ('ROTATION', Vector((0, 0, 0)), Vector((0, 0, math.radians(720)))),
            ('SCALE', Vector((0.3, 0.3, 0.3)), orig_scale),
            ('LOCATION', Vector((orig_loc.x + 1, orig_loc.y + 1, orig_loc.z + 1)), orig_loc),
            ('ROTATION', Vector((0, 0, math.radians(720))), orig_rot),
        ],
        'BOUNCE_DROP': [
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 8)), Vector((orig_loc.x, orig_loc.y, orig_loc.z))),
            ('SCALE', Vector((1.0, 1.0, 1.0)), Vector((1.2, 1.2, 0.7))),
            ('SCALE', Vector((1.2, 1.2, 0.7)), Vector((0.9, 0.9, 1.1))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z)), Vector((orig_loc.x, orig_loc.y, orig_loc.z + 2))),
            ('LOCATION', Vector((orig_loc.x, orig_loc.y, orig_loc.z + 2)), orig_loc),
            ('SCALE', Vector((0.9, 0.9, 1.1)), Vector((1.05, 1.05, 0.95))),
            ('SCALE', Vector((1.05, 1.05, 0.95)), orig_scale),
        ],
        'ELASTIC_POP': [
            ('SCALE', Vector((0, 0, 0)), Vector((1.5, 1.5, 1.5))),
            ('SCALE', Vector((1.5, 1.5, 1.5)), Vector((0.7, 0.7, 0.7))),
            ('SCALE', Vector((0.7, 0.7, 0.7)), Vector((1.2, 1.2, 1.2))),
            ('SCALE', Vector((1.2, 1.2, 1.2)), Vector((0.9, 0.9, 0.9))),
            ('SCALE', Vector((0.9, 0.9, 0.9)), orig_scale),
            ('ROTATION', Vector((0, 0, random.uniform(-0.2, 0.2))), orig_rot),
        ],
        'DOMINO_FALL': [
            ('ROTATION', orig_rot, Vector((orig_rot.x + math.radians(90), orig_rot.y, orig_rot.z))),
            ('LOCATION', orig_loc, Vector((orig_loc.x + random.uniform(0.2, 0.5), orig_loc.y, orig_loc.z - 0.3))),
        ],
    }

    return preset_sequences.get(preset_type)


def apply_preset_animation(operator, context, obj, start_frame: int, preset_type: str) -> bool:
    """Apply a preset animation sequence to *obj*."""
    props = context.scene.vectart_animation_props

    sequence = get_preset_sequence(preset_type, obj, props)
    if not sequence:
        print(f"Unknown preset type: {preset_type}")
        return False

    try:
        # Clear existing animation
        if obj.animation_data:
            obj.animation_data_clear()
        obj.animation_data_create()

        current_start = 0
        for action_index, (action_type, start_value, end_value) in enumerate(sequence):
            current_start = start_frame + calculate_sequence_timing(
                props,
                obj.get('animation_index', 0),
                len(context.selected_objects),
                action_index,
            )

            if action_type == 'SCALE':
                obj.scale = start_value
                obj.keyframe_insert(data_path="scale", frame=current_start)
                obj.scale = end_value
                obj.keyframe_insert(data_path="scale", frame=current_start + props.frames_per_object)

            elif action_type == 'ROTATION':
                obj.rotation_euler = start_value
                obj.keyframe_insert(data_path="rotation_euler", frame=current_start)
                obj.rotation_euler = end_value
                obj.keyframe_insert(data_path="rotation_euler", frame=current_start + props.frames_per_object)

            elif action_type == 'LOCATION':
                obj.location = start_value
                obj.keyframe_insert(data_path="location", frame=current_start)
                obj.location = end_value
                obj.keyframe_insert(data_path="location", frame=current_start + props.frames_per_object)

        # Handle curve bevel
        if obj.type == 'CURVE' and hasattr(obj.data, "bevel_depth"):
            obj.data.bevel_depth = 0.0
            obj.data.keyframe_insert("bevel_depth", frame=current_start)
            obj.data.bevel_depth = props.extrude_end
            obj.data.keyframe_insert("bevel_depth", frame=current_start + props.frames_per_object)

        # Apply easing
        if obj.animation_data and obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                for keyframe in fcurve.keyframe_points:
                    keyframe.interpolation = props.preset_animation_interpolation
                    keyframe.easing = props.preset_animation_easing

        return True

    except Exception as e:
        operator.report({'WARNING'}, f"Error creating animation: {e}")
        return False


def validate_collection_name(name: str) -> bool:
    """Return False if the collection name is in the exclusion list."""
    forbidden_names = {'cameras', 'lights', 'bg'}
    return name.lower() not in forbidden_names
