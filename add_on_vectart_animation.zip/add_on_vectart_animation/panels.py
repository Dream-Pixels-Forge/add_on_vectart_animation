# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""UI Panel definitions for VectArt Animation.

Key design choice: Create Animation / Apply Preset / Clear Animation buttons
are placed directly in the main panel for immediate discoverability, as
requested by users who found them difficult to locate inside sub-panels.
"""

import bpy
from bpy.types import Panel, UIList


# =============================================================================
# UI Lists
# =============================================================================


class VECTART_UL_CollectionList(UIList):
    """List widget for animation collections."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            ico = 'COLLECTION_COLOR_05' if item.active else 'STRIP_COLOR_01'
            row.prop(item, "active", text="", icon=ico, emboss=False)
            row.prop(item, "name", text="", emboss=False)
            if item.collection:
                row.label(text=f"({len(item.collection.objects)})")


class VECTART_UL_PresetList(UIList):
    """List widget for animation presets."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            ico = item.icon if item.icon != "NONE" else 'NONE'
            row.prop(item, "name", text="", emboss=False, icon=ico)


# =============================================================================
# Main Panel
# =============================================================================


class VECTART_PT_MainPanel(Panel):
    """VectArt Animation - Main Panel"""

    bl_label = "VectArt Animation"
    bl_idname = "VECTART_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        # -- Collection Management --
        box = layout.box()
        box.label(text="Collections", icon='MOD_BUILD')

        row = box.row()
        row.template_list(
            "VECTART_UL_CollectionList", "",
            props, "collections",
            props, "active_collection_index",
            rows=3,
        )

        col = row.column(align=True)
        col.operator("vectart.add_collection", text="", icon='ADD')
        col.operator("vectart.remove_collection", text="", icon='REMOVE')
        col.operator("vectart.clear_collections", text="", icon='X')
        col.operator("vectart.refresh_collections", text="", icon='FILE_REFRESH')

        # -- Timing Settings --
        box = layout.box()
        box.label(text="Timing Settings", icon='TIME')
        grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        grid.prop(props, "animation_start_frame")
        grid.prop(props, "auto_duration")
        grid.prop(props, "delay_mode")
        grid.prop(props, "musicality", slider=True)

        if props.auto_duration:
            grid.prop(props, "frames_per_object")
            obj_count = 0
            if (
                props.collections
                and 0 <= props.active_collection_index < len(props.collections)
            ):
                coll = props.collections[props.active_collection_index].collection
                if coll:
                    obj_count = len([o for o in coll.objects if o.type in {'MESH', 'CURVE'}])
            if obj_count > 0:
                total_frames = obj_count * props.frames_per_object
                grid.label(text=f"Total: {total_frames} frames")
        else:
            grid.prop(props, "duration")

        # -- Delay Properties --
        if props.delay_mode != 'NONE':
            box = layout.box()
            box.label(text="Delay Properties", icon='OPTIONS')
            col = box.column(align=True)
            col.prop(props, "delay_amount")
            if props.delay_mode == 'RANDOM':
                col.prop(props, "random_seed")
            elif props.delay_mode == 'OVERLAP':
                col.prop(props, "overlap_div")

        # =====================================================================
        # ACTION BUTTONS - Prominently placed in the main panel
        # =====================================================================
        layout.separator()
        action_box = layout.box()
        action_box.label(text="Actions", icon='PLAY')

        row = action_box.row(align=True)
        row.scale_y = 2.0

        if props.animation_mode == 'DEFAULT':
            row.operator("vectart.default_animation", icon='PLAY', text="Create Animation")
        elif props.animation_mode == 'PRESET':
            row.operator("vectart.apply_preset", icon='CHECKMARK', text="Apply Preset")
        elif props.animation_mode == 'GEOMETRY_NODES':
            row.operator("vectart.apply_gn_preset", icon='GEOMETRY_NODES', text="Apply GN Effect")

        row.operator("vectart.clear_animation", icon='CANCEL', text="Clear Animation")

        # GN removal button when in GN mode
        if props.animation_mode == 'GEOMETRY_NODES':
            row2 = action_box.row(align=True)
            row2.operator("vectart.remove_gn_presets", icon='X', text="Remove GN Effects")


# =============================================================================
# Style Sub-Panel
# =============================================================================


class VECTART_PT_StylePanel(Panel):
    """Animation style and type settings"""

    bl_label = "Style Settings"
    bl_idname = "VECTART_PT_style"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        layout.prop(props, "animation_mode")

        if props.animation_mode == 'DEFAULT':
            self._draw_default_mode(layout, props, context)
        elif props.animation_mode == 'PRESET':
            self._draw_preset_mode(layout, props)
        elif props.animation_mode == 'GEOMETRY_NODES':
            self._draw_gn_mode(layout, props)

    def _draw_default_mode(self, layout, props, context):
        box = layout.box()
        box.label(text="Animation Types")
        grid = box.grid_flow(row_major=True, columns=2, even_columns=True)

        # Scale
        col = grid.column()
        row = col.row()
        row.prop(props, "use_scale", text="Scale", toggle=True)
        if props.use_scale:
            row.prop(props, "scale_offset", text="Offset")

        # Rotation
        col = grid.column()
        row = col.row()
        row.prop(props, "use_rotation", text="Rotation", toggle=True)
        if props.use_rotation:
            row.prop(props, "rotation_offset", text="Offset")

        # Location
        col = grid.column()
        row = col.row()
        row.prop(props, "use_location", text="Location", toggle=True)
        if props.use_location:
            row.prop(props, "location_offset", text="Offset")

        # Extrude
        if any(obj.type == 'CURVE' for obj in context.selected_objects):
            col = grid.column()
            row = col.row()
            row.prop(props, "use_extrude", text="Extrude", toggle=True)
            if props.use_extrude:
                row.prop(props, "extrude_offset", text="Offset")

        # Detail settings for enabled types
        if props.use_scale:
            box = layout.box()
            box.label(text="Scale Settings")
            split = box.split()
            split.column().prop(props, "scale_min")
            split.column().prop(props, "scale_final")
            box.prop(props, "maintain_proportions")

        if props.use_rotation:
            box = layout.box()
            box.label(text="Rotation Settings")
            col = box.column(align=True)
            col.prop(props, "rotation_axis")
            col.prop(props, "rotation_angle")
            col.prop(props, "rotation_direction")

        if props.use_location:
            box = layout.box()
            box.label(text="Location Settings")
            split = box.split()
            lbl = "Start Offset:" if props.use_relative_location else "Start Position:"
            left = split.column()
            left.label(text=lbl)
            left.prop(props, "location_start", text="")
            lbl = "End Offset:" if props.use_relative_location else "End Position:"
            right = split.column()
            right.label(text=lbl)
            right.prop(props, "location_end", text="")
            box.prop(props, "use_relative_location")

        if props.use_extrude and any(obj.type == 'CURVE' for obj in context.selected_objects):
            box = layout.box()
            box.label(text="Extrude Settings")
            col = box.column(align=True)
            col.prop(props, "extrude_start")
            col.prop(props, "extrude_end")
            col.prop(props, "extrude_steps")

    def _draw_preset_mode(self, layout, props):
        row = layout.row(align=True)
        row.operator("vectart.refresh_presets", icon='FILE_REFRESH', text="Refresh Presets")

        layout.template_list(
            "VECTART_UL_PresetList", "",
            props, "presets",
            props, "active_preset_index",
            rows=3,
        )

        if props.presets and props.active_preset_index >= 0:
            preset = props.presets[props.active_preset_index]
            layout.label(text=preset.description)

        box = layout.box()
        box.label(text="Collision Settings")
        box.prop(props, "use_collision_detection")
        if props.use_collision_detection:
            box.prop(props, "collision_margin")

    def _draw_gn_mode(self, layout, props):
        """Draw geometry nodes preset controls."""
        box = layout.box()
        box.label(text="Geometry Nodes Presets", icon='GEOMETRY_NODES')

        box.prop(props, "gn_preset")
        col = box.column(align=True)
        col.prop(props, "gn_duration")
        col.prop(props, "gn_strength")

        # Randomize per object
        box2 = layout.box()
        box2.label(text="Per-Object Variation", icon='MOD_NOISE')
        box2.prop(props, "gn_randomize_per_object")
        if props.gn_randomize_per_object:
            box2.prop(props, "gn_variation_amount", slider=True)

        layout.separator()
        box = layout.box()
        box.label(text="Info", icon='INFO')
        box.label(text="Applies procedural GN modifier with")
        box.label(text="keyframed inputs to mesh objects.")
        box.label(text="(Mesh objects only)")


# =============================================================================
# Advanced Sub-Panel
# =============================================================================


class VECTART_PT_AdvancedPanel(Panel):
    """Advanced interpolation and flow settings"""

    bl_label = "Advanced Settings"
    bl_idname = "VECTART_PT_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        box = layout.box()
        box.label(text="Interpolation / Animation Flow")
        split = box.split()

        left = split.column()
        left.prop(props, "preset_animation_interpolation")
        left.prop(props, "preset_animation_easing")

        right = split.column()
        right.prop(props, "animation_velocity")
        right.prop(props, "layer_animation_order")

        box.prop(props, "use_local_axis")


# =============================================================================
# Tools Sub-Panel
# =============================================================================


class VECTART_PT_ToolsPanel(Panel):
    """Quick select, object management, and keyframe tools"""

    bl_label = "Tools"
    bl_idname = "VECTART_PT_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'VectArt'
    bl_parent_id = "VECTART_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.vectart_animation_props

        # Quick Select
        box = layout.box()
        box.label(text="Quick Select", icon='RESTRICT_SELECT_OFF')
        row = box.row(align=True)
        row.operator("vectart.select_collection_objects", text="All").select_type = 'ALL'
        row.operator("vectart.select_collection_objects", text="Curves").select_type = 'CURVES'
        row.operator("vectart.select_collection_objects", text="Meshes").select_type = 'MESHES'

        # Object Management / State Caching
        box = layout.box()
        box.label(text="State Management", icon='OBJECT_DATA')
        row = box.row(align=True)
        row.operator("vectart.store_state", icon='FILE_TICK', text="Store State")
        row.operator("vectart.restore_state", icon='LOOP_BACK', text="Restore State")
        box.operator("vectart.initialize_objects", icon='IMPORT', text="Store Transforms (Legacy)")

        # NLA
        box = layout.box()
        box.label(text="NLA Compositing", icon='NLA')
        box.operator("vectart.push_to_nla", icon='NLA_PUSHDOWN', text="Push to NLA Track")
        box.label(text="Layer multiple animations on same objects", icon='INFO')

        # Keyframe Tools
        box = layout.box()
        box.label(text="Keyframe Tools", icon='ACTION')
        box.prop(props, "paste_target_frame")
        row = box.row(align=True)
        row.operator("vectart.copy_keyframes", icon='COPYDOWN')
        row.operator("vectart.paste_keyframes_reverse", icon='PASTEDOWN')

        # Batch Export
        box = layout.box()
        box.label(text="Export", icon='EXPORT')
        box.operator("vectart.batch_export", icon='EXPORT', text="Batch Export (FBX)")


# =============================================================================
# Registration
# =============================================================================

_classes = (
    VECTART_UL_CollectionList,
    VECTART_UL_PresetList,
    VECTART_PT_MainPanel,
    VECTART_PT_StylePanel,
    VECTART_PT_AdvancedPanel,
    VECTART_PT_ToolsPanel,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
