# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""Property group definitions for VectArt Animation."""

import math

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


# -----------------------------------------------------------------------------
# Update Callbacks
# -----------------------------------------------------------------------------

def _update_collision_settings(self, context):
    """Refresh viewport when collision settings change."""
    if context.area:
        context.area.tag_redraw()


# -----------------------------------------------------------------------------
# Property Groups
# -----------------------------------------------------------------------------

class VectartCollectionItem(PropertyGroup):
    """Represents a single collection entry in the animation list."""

    name: StringProperty(default="Collection")  # type: ignore[assignment]
    active: BoolProperty(default=True)  # type: ignore[assignment]
    collection: PointerProperty(type=bpy.types.Collection)  # type: ignore[assignment]


class PresetItem(PropertyGroup):
    """Represents an animation preset entry."""

    name: StringProperty(default="Preset")  # type: ignore[assignment]
    preset_id: StringProperty()  # type: ignore[assignment]
    icon: StringProperty(default="NONE")  # type: ignore[assignment]
    description: StringProperty()  # type: ignore[assignment]


class VectartAnimationProperties(PropertyGroup):
    """Main property group holding all animation settings."""

    # -- Collection Management --
    collections: CollectionProperty(type=VectartCollectionItem)  # type: ignore[assignment]
    active_collection_index: IntProperty()  # type: ignore[assignment]

    # -- Animation Timing --
    animation_start_frame: IntProperty(
        name="Start Frame",
        default=1,
        min=1,
    )  # type: ignore[assignment]
    auto_duration: BoolProperty(
        name="Auto Duration",
        default=True,
    )  # type: ignore[assignment]
    frames_per_object: IntProperty(
        name="Frames Per Object",
        default=6,
        min=1,
    )  # type: ignore[assignment]
    duration: IntProperty(
        name="Duration",
        default=50,
        min=1,
    )  # type: ignore[assignment]

    delay_mode: EnumProperty(
        name="Delay Mode",
        items=[
            ('NONE', "None", "No delay between objects"),
            ('SEQUENTIAL', "Sequential", "Sequential delay between objects"),
            ('RANDOM', "Random", "Random delay between objects"),
            ('OVERLAP', "Overlap", "Objects overlap animation"),
        ],
        default='SEQUENTIAL',
    )  # type: ignore[assignment]
    delay_amount: FloatProperty(
        name="Delay",
        description="Delay amount in frames",
        default=5.0,
        min=0.0,
    )  # type: ignore[assignment]
    random_seed: IntProperty(
        name="Random Seed",
        description="Seed for random delay generation",
        default=1234,
        min=1,
    )  # type: ignore[assignment]
    overlap_div: FloatProperty(
        name="Overlap",
        description="Amount of overlap between animations (0.1 = minimal, 1.0 = full)",
        default=0.85,
        min=0.1,
        max=1.0,
        precision=2,
    )  # type: ignore[assignment]

    # -- Animation Preset --
    animation_preset: EnumProperty(
        name="Animation Preset",
        items=[
            ('ROBOTIC_UNFOLD', "Robotic Unfold", "Robotic unfolding animation"),
            ('ROBOTIC_TRANSFORM', "Robotic Transform", "Complex transformation sequence"),
            ('TECH_ASSEMBLY', "Tech Assembly", "Technical assembly animation"),
            ('MECH_STARTUP', "Mech Startup", "Mechanical startup sequence"),
            ('ORIGAMI', "Origami", "Complex origami folding and unfolding animation"),
            ('HOLOGRAPHIC_APPEAR', "Holographic", "Holographic appearance effect"),
            ('GLITCH_APPEAR', "Glitch", "Glitch appearance effect"),
            ('ASSEMBLE', "Assemble", "Parts assembly animation"),
            ('MAGNETIC', "Magnetic", "Magnetic attraction animation"),
            ('EXPLODE', "Explode", "Object explosion animation"),
        ],
        default='ROBOTIC_UNFOLD',
    )  # type: ignore[assignment]

    # -- Interpolation --
    animation_interpolation: EnumProperty(
        name="Interpolation",
        items=[
            ('LINEAR', "Linear", "Linear interpolation"),
            ('BEZIER', "Bezier", "Bezier curve interpolation"),
            ('CONSTANT', "Constant", "No interpolation"),
        ],
        default='LINEAR',
    )  # type: ignore[assignment]

    # -- Animation Flow --
    animation_velocity: EnumProperty(
        name="Velocity",
        items=[
            ('UNIFORM', "Uniform", "Constant speed"),
            ('ACCELERATE', "Accelerate", "Increasing speed"),
            ('DECELERATE', "Decelerate", "Decreasing speed"),
        ],
        default='ACCELERATE',
    )  # type: ignore[assignment]

    layer_animation_order: EnumProperty(
        name="Layer Order",
        items=[
            ('TOP_DOWN', "Top Down", "Animate from top layer to bottom"),
            ('BOTTOM_UP', "Bottom Up", "Animate from bottom layer to top"),
            ('SIMULTANEOUS', "Simultaneous", "Animate all layers at once"),
        ],
        default='BOTTOM_UP',
    )  # type: ignore[assignment]

    use_local_axis: BoolProperty(
        name="Use Local Axis",
        description="Use object's local axis for animations",
        default=False,
    )  # type: ignore[assignment]

    # -- Animation Mode --
    animation_mode: EnumProperty(
        name="Animation Mode",
        items=[
            ('DEFAULT', "Default", "Standard keyframe animation"),
            ('PRESET', "Preset", "Predefined animation presets"),
        ],
        default='DEFAULT',
    )  # type: ignore[assignment]

    default_type: EnumProperty(
        name="Animation Type",
        items=[
            ('SCALE', "Scale", "Scale animation"),
            ('ROTATE', "Rotate", "Rotation animation"),
            ('LOCATION', "Location", "Location animation"),
            ('EXTRUDE', "Extrude", "Extrude animation"),
        ],
        default='SCALE',
    )  # type: ignore[assignment]

    # -- Animation Combination Toggles --
    use_scale: BoolProperty(
        name="Scale",
        description="Apply scale animation",
        default=True,
    )  # type: ignore[assignment]
    use_rotation: BoolProperty(
        name="Rotation",
        description="Apply rotation animation",
        default=False,
    )  # type: ignore[assignment]
    use_location: BoolProperty(
        name="Location",
        description="Apply location animation",
        default=False,
    )  # type: ignore[assignment]
    use_extrude: BoolProperty(
        name="Extrude",
        description="Apply extrude animation (curves only)",
        default=False,
    )  # type: ignore[assignment]

    # -- Animation Timing Offsets --
    scale_offset: IntProperty(
        name="Scale Offset",
        description="Frame offset for scale animation",
        default=0,
        min=0,
    )  # type: ignore[assignment]
    rotation_offset: IntProperty(
        name="Rotation Offset",
        description="Frame offset for rotation animation",
        default=10,
        min=0,
    )  # type: ignore[assignment]
    location_offset: IntProperty(
        name="Location Offset",
        description="Frame offset for location animation",
        default=0,
        min=0,
    )  # type: ignore[assignment]
    extrude_offset: IntProperty(
        name="Extrude Offset",
        description="Frame offset for extrude animation",
        default=0,
        min=0,
    )  # type: ignore[assignment]

    # -- Preset Management --
    presets: CollectionProperty(type=PresetItem)  # type: ignore[assignment]
    active_preset_index: IntProperty(default=0)  # type: ignore[assignment]

    # -- Scale Settings --
    scale_final: FloatVectorProperty(
        name="Final Scale",
        default=(1.0, 1.0, 1.0),
        subtype='XYZ',
    )  # type: ignore[assignment]
    scale_min: FloatVectorProperty(
        name="Start Scale",
        default=(0.0, 0.0, 0.0),
        subtype='XYZ',
    )  # type: ignore[assignment]
    maintain_proportions: BoolProperty(
        name="Maintain Proportions",
        default=True,
    )  # type: ignore[assignment]

    # -- Rotation Settings --
    rotation_axis: EnumProperty(
        name="Rotation Axis",
        items=[
            ('X', "X", "Rotate around X axis"),
            ('Y', "Y", "Rotate around Y axis"),
            ('Z', "Z", "Rotate around Z axis"),
        ],
        default='Z',
    )  # type: ignore[assignment]
    rotation_angle: FloatProperty(
        name="Angle",
        default=math.radians(360.0),
        subtype='ANGLE',
        unit='ROTATION',
    )  # type: ignore[assignment]
    rotation_direction: EnumProperty(
        name="Direction",
        items=[
            ('CW', "Clockwise", "Clockwise rotation"),
            ('CCW', "Counter-Clockwise", "Counter-clockwise rotation"),
        ],
        default='CW',
    )  # type: ignore[assignment]

    # -- Location Settings --
    use_relative_location: BoolProperty(
        name="Relative Movement",
        default=True,
    )  # type: ignore[assignment]
    location_start: FloatVectorProperty(
        name="Start",
        default=(0.0, 0.0, 2.0),
        subtype='TRANSLATION',
    )  # type: ignore[assignment]
    location_end: FloatVectorProperty(
        name="End",
        default=(0.0, 0.0, 0.0),
        subtype='TRANSLATION',
    )  # type: ignore[assignment]

    # -- Extrude Settings --
    extrude_start: FloatProperty(
        name="Start",
        default=0.0,
        min=0.0,
    )  # type: ignore[assignment]
    extrude_end: FloatProperty(
        name="End",
        default=0.01,
        min=0.0,
    )  # type: ignore[assignment]
    extrude_steps: IntProperty(
        name="Steps",
        default=10,
        min=1,
    )  # type: ignore[assignment]

    # -- Keyframe Tools --
    paste_target_frame: IntProperty(
        name="Target Frame",
        description="Frame to start pasting reversed animation",
        default=60,
        min=1,
    )  # type: ignore[assignment]

    # -- Collision Detection --
    use_collision_detection: BoolProperty(
        name="Use Collision Detection",
        description="Enable smart collision detection for animations",
        default=True,
        update=_update_collision_settings,
    )  # type: ignore[assignment]
    collision_margin: FloatProperty(
        name="Collision Margin",
        description="Extra space to maintain between objects",
        default=0.1,
        min=0.0,
        max=1.0,
        update=_update_collision_settings,
    )  # type: ignore[assignment]

    # -- Preset Interpolation & Easing --
    preset_animation_interpolation: EnumProperty(
        name="Interpolation",
        description="Animation interpolation type",
        items=[
            ('LINEAR', "Linear", "Linear interpolation"),
            ('BOUNCE', "Bounce", "Bounce interpolation"),
            ('ELASTIC', "Elastic", "Elastic interpolation"),
            ('BACK', "Back", "Back interpolation"),
            ('SINE', "Sine", "Sinusoidal interpolation"),
            ('EXPO', "Exponential", "Exponential interpolation"),
            ('CIRC', "Circular", "Strong and dramatic"),
        ],
        default='EXPO',
    )  # type: ignore[assignment]
    preset_animation_easing: EnumProperty(
        name="Easing",
        description="Animation easing type",
        items=[
            ('EASE_IN', "Ease In", "Ease in"),
            ('EASE_OUT', "Ease Out", "Ease out"),
            ('EASE_IN_OUT', "Ease In-Out", "Ease in and out"),
        ],
        default='EASE_OUT',
    )  # type: ignore[assignment]

    # -- Musicality --
    musicality: FloatProperty(
        name="Musicality",
        description="Controls the overlap and orchestration of actions (higher = more overlap)",
        default=0.5,
        min=0.0,
        max=2.0,
        step=1,
        precision=2,
    )  # type: ignore[assignment]


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------

_classes = (
    VectartCollectionItem,
    PresetItem,
    VectartAnimationProperties,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.vectart_animation_props = PointerProperty(
        type=VectartAnimationProperties
    )


def unregister():
    del bpy.types.Scene.vectart_animation_props

    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
