# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""Geometry Nodes animation presets for VectArt Animation.

This module creates procedural geometry node setups that produce animated effects
such as wave deformation, noise displacement, dissolve, and scatter.
Each preset is a self-contained node group with keyframed inputs.
"""

from __future__ import annotations

import bpy
from mathutils import Vector

# Unique prefix to identify addon-created node groups
_GN_PREFIX = "VA_GeoAnim_"


# =============================================================================
# Node Group Builders
# =============================================================================


def _ensure_group_io(node_tree):
    """Return (group_input_node, group_output_node), creating them if absent."""
    input_node = None
    output_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP_INPUT':
            input_node = node
        elif node.type == 'GROUP_OUTPUT':
            output_node = node

    if not input_node:
        input_node = node_tree.nodes.new('NodeGroupInput')
        input_node.location = (-400, 0)
    if not output_node:
        output_node = node_tree.nodes.new('NodeGroupOutput')
        output_node.location = (400, 0)

    return input_node, output_node


def _add_interface_socket(node_tree, name: str, socket_type: str, in_out: str, **kwargs):
    """Add an interface socket (input or output) to the node tree.

    Compatible with Blender 4.0+ interface API.
    socket_type: e.g. 'NodeSocketFloat', 'NodeSocketGeometry', 'NodeSocketVector'
    in_out: 'INPUT' or 'OUTPUT'
    """
    item = node_tree.interface.new_socket(
        name=name,
        socket_type=socket_type,
        in_out=in_out,
    )
    # Set default/min/max if applicable
    if hasattr(item, 'default_value') and 'default' in kwargs:
        item.default_value = kwargs['default']
    if hasattr(item, 'min_value') and 'min_value' in kwargs:
        item.min_value = kwargs['min_value']
    if hasattr(item, 'max_value') and 'max_value' in kwargs:
        item.max_value = kwargs['max_value']
    return item


def create_wave_deform_group() -> bpy.types.NodeTree:
    """Create a Geometry Nodes group that applies animated wave deformation.

    Inputs:
        - Geometry (passthrough)
        - Amplitude (float, keyframed 0 -> value -> 0)
        - Frequency (float)
        - Phase (float, keyframed for animated wave travel)
    """
    name = _GN_PREFIX + "Wave_Deform"

    # Reuse if exists
    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]

    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.nodes.clear()

    # Interface
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'INPUT')
    _add_interface_socket(ng, "Amplitude", 'NodeSocketFloat', 'INPUT', default=0.0, min_value=0.0, max_value=10.0)
    _add_interface_socket(ng, "Frequency", 'NodeSocketFloat', 'INPUT', default=2.0, min_value=0.1, max_value=20.0)
    _add_interface_socket(ng, "Phase", 'NodeSocketFloat', 'INPUT', default=0.0)
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'OUTPUT')

    input_node, output_node = _ensure_group_io(ng)

    # Position node
    pos_node = ng.nodes.new('GeometryNodeInputPosition')
    pos_node.location = (-200, -100)

    # Separate XYZ
    sep_node = ng.nodes.new('ShaderNodeSeparateXYZ')
    sep_node.location = (-50, -100)
    ng.links.new(pos_node.outputs['Position'], sep_node.inputs['Vector'])

    # Math: X * Frequency + Phase -> sin
    multiply_node = ng.nodes.new('ShaderNodeMath')
    multiply_node.operation = 'MULTIPLY'
    multiply_node.location = (100, -50)
    ng.links.new(sep_node.outputs['X'], multiply_node.inputs[0])
    ng.links.new(input_node.outputs['Frequency'], multiply_node.inputs[1])

    add_phase = ng.nodes.new('ShaderNodeMath')
    add_phase.operation = 'ADD'
    add_phase.location = (250, -50)
    ng.links.new(multiply_node.outputs['Value'], add_phase.inputs[0])
    ng.links.new(input_node.outputs['Phase'], add_phase.inputs[1])

    sin_node = ng.nodes.new('ShaderNodeMath')
    sin_node.operation = 'SINE'
    sin_node.location = (400, -50)
    ng.links.new(add_phase.outputs['Value'], sin_node.inputs[0])

    # Multiply by Amplitude
    amp_mult = ng.nodes.new('ShaderNodeMath')
    amp_mult.operation = 'MULTIPLY'
    amp_mult.location = (550, -50)
    ng.links.new(sin_node.outputs['Value'], amp_mult.inputs[0])
    ng.links.new(input_node.outputs['Amplitude'], amp_mult.inputs[1])

    # Combine XYZ for offset (0, 0, result)
    combine_node = ng.nodes.new('ShaderNodeCombineXYZ')
    combine_node.location = (700, -50)
    combine_node.inputs['X'].default_value = 0.0
    combine_node.inputs['Y'].default_value = 0.0
    ng.links.new(amp_mult.outputs['Value'], combine_node.inputs['Z'])

    # Set Position
    set_pos = ng.nodes.new('GeometryNodeSetPosition')
    set_pos.location = (900, 0)
    ng.links.new(input_node.outputs['Geometry'], set_pos.inputs['Geometry'])
    ng.links.new(combine_node.outputs['Vector'], set_pos.inputs['Offset'])

    # Output
    ng.links.new(set_pos.outputs['Geometry'], output_node.inputs['Geometry'])

    return ng


def create_noise_displacement_group() -> bpy.types.NodeTree:
    """Create a GN group that displaces vertices using 3D noise.

    Inputs:
        - Geometry
        - Strength (float, keyframed)
        - Scale (float, noise detail level)
        - Offset (float, animated for flowing noise)
    """
    name = _GN_PREFIX + "Noise_Displace"

    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]

    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.nodes.clear()

    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'INPUT')
    _add_interface_socket(ng, "Strength", 'NodeSocketFloat', 'INPUT', default=0.0, min_value=0.0, max_value=5.0)
    _add_interface_socket(ng, "Scale", 'NodeSocketFloat', 'INPUT', default=3.0, min_value=0.1, max_value=20.0)
    _add_interface_socket(ng, "Offset", 'NodeSocketFloat', 'INPUT', default=0.0)
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'OUTPUT')

    input_node, output_node = _ensure_group_io(ng)

    # Position
    pos_node = ng.nodes.new('GeometryNodeInputPosition')
    pos_node.location = (-300, -150)

    # Vector Math: Position + (Offset, Offset, Offset)
    offset_combine = ng.nodes.new('ShaderNodeCombineXYZ')
    offset_combine.location = (-150, -250)
    ng.links.new(input_node.outputs['Offset'], offset_combine.inputs['X'])
    ng.links.new(input_node.outputs['Offset'], offset_combine.inputs['Y'])
    ng.links.new(input_node.outputs['Offset'], offset_combine.inputs['Z'])

    vec_add = ng.nodes.new('ShaderNodeVectorMath')
    vec_add.operation = 'ADD'
    vec_add.location = (0, -150)
    ng.links.new(pos_node.outputs['Position'], vec_add.inputs[0])
    ng.links.new(offset_combine.outputs['Vector'], vec_add.inputs[1])

    # Noise Texture
    noise_node = ng.nodes.new('ShaderNodeTexNoise')
    noise_node.noise_dimensions = '3D'
    noise_node.location = (200, -150)
    ng.links.new(vec_add.outputs['Vector'], noise_node.inputs['Vector'])
    ng.links.new(input_node.outputs['Scale'], noise_node.inputs['Scale'])

    # Map Range: Noise Fac (0-1) -> (-1, 1)
    map_range = ng.nodes.new('ShaderNodeMapRange')
    map_range.location = (400, -150)
    map_range.inputs['From Min'].default_value = 0.0
    map_range.inputs['From Max'].default_value = 1.0
    map_range.inputs['To Min'].default_value = -1.0
    map_range.inputs['To Max'].default_value = 1.0
    ng.links.new(noise_node.outputs['Fac'], map_range.inputs['Value'])

    # Normal
    normal_node = ng.nodes.new('GeometryNodeInputNormal')
    normal_node.location = (200, -350)

    # Vector Math: Normal * mapped_noise * Strength
    scale_normal = ng.nodes.new('ShaderNodeVectorMath')
    scale_normal.operation = 'SCALE'
    scale_normal.location = (600, -200)
    ng.links.new(normal_node.outputs['Normal'], scale_normal.inputs[0])
    ng.links.new(map_range.outputs['Result'], scale_normal.inputs['Scale'])

    strength_scale = ng.nodes.new('ShaderNodeVectorMath')
    strength_scale.operation = 'SCALE'
    strength_scale.location = (800, -200)
    ng.links.new(scale_normal.outputs['Vector'], strength_scale.inputs[0])
    ng.links.new(input_node.outputs['Strength'], strength_scale.inputs['Scale'])

    # Set Position
    set_pos = ng.nodes.new('GeometryNodeSetPosition')
    set_pos.location = (1000, 0)
    ng.links.new(input_node.outputs['Geometry'], set_pos.inputs['Geometry'])
    ng.links.new(strength_scale.outputs['Vector'], set_pos.inputs['Offset'])

    ng.links.new(set_pos.outputs['Geometry'], output_node.inputs['Geometry'])

    return ng


def create_dissolve_group() -> bpy.types.NodeTree:
    """Create a GN group that dissolves geometry by deleting random faces.

    Inputs:
        - Geometry
        - Factor (float 0-1, keyframed: 0 = full mesh, 1 = fully dissolved)
        - Seed (int)
    """
    name = _GN_PREFIX + "Dissolve"

    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]

    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.nodes.clear()

    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'INPUT')
    _add_interface_socket(ng, "Factor", 'NodeSocketFloat', 'INPUT', default=0.0, min_value=0.0, max_value=1.0)
    _add_interface_socket(ng, "Seed", 'NodeSocketInt', 'INPUT', default=0)
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'OUTPUT')

    input_node, output_node = _ensure_group_io(ng)

    # Random Value per face
    random_node = ng.nodes.new('FunctionNodeRandomValue')
    random_node.data_type = 'FLOAT'
    random_node.location = (0, -100)
    random_node.inputs['Min'].default_value = 0.0
    random_node.inputs['Max'].default_value = 1.0
    ng.links.new(input_node.outputs['Seed'], random_node.inputs['Seed'])

    # Compare: random < Factor => delete
    compare_node = ng.nodes.new('FunctionNodeCompare')
    compare_node.data_type = 'FLOAT'
    compare_node.operation = 'LESS_THAN'
    compare_node.location = (200, -100)
    ng.links.new(random_node.outputs['Value'], compare_node.inputs['A'])
    ng.links.new(input_node.outputs['Factor'], compare_node.inputs['B'])

    # Delete Geometry
    delete_node = ng.nodes.new('GeometryNodeDeleteGeometry')
    delete_node.domain = 'FACE'
    delete_node.location = (400, 0)
    ng.links.new(input_node.outputs['Geometry'], delete_node.inputs['Geometry'])
    ng.links.new(compare_node.outputs['Result'], delete_node.inputs['Selection'])

    ng.links.new(delete_node.outputs['Geometry'], output_node.inputs['Geometry'])

    return ng


def create_scatter_instances_group() -> bpy.types.NodeTree:
    """Create a GN group that scatters instances on surface with animated density.

    Inputs:
        - Geometry (base mesh)
        - Density (float, keyframed: 0 -> max -> 0 for grow/shrink effect)
        - Scale (float, instance scale)
        - Seed (int)
    """
    name = _GN_PREFIX + "Scatter"

    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]

    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.nodes.clear()

    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'INPUT')
    _add_interface_socket(ng, "Density", 'NodeSocketFloat', 'INPUT', default=0.0, min_value=0.0, max_value=100.0)
    _add_interface_socket(ng, "Scale", 'NodeSocketFloat', 'INPUT', default=0.1, min_value=0.001, max_value=5.0)
    _add_interface_socket(ng, "Seed", 'NodeSocketInt', 'INPUT', default=0)
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'OUTPUT')

    input_node, output_node = _ensure_group_io(ng)

    # Distribute Points on Faces
    distribute = ng.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute.distribute_method = 'RANDOM'
    distribute.location = (100, 0)
    ng.links.new(input_node.outputs['Geometry'], distribute.inputs['Mesh'])
    ng.links.new(input_node.outputs['Density'], distribute.inputs['Density'])
    ng.links.new(input_node.outputs['Seed'], distribute.inputs['Seed'])

    # Instance on Points (using Ico Sphere as placeholder)
    ico = ng.nodes.new('GeometryNodeMeshIcoSphere')
    ico.location = (100, -250)
    ico.inputs['Radius'].default_value = 1.0
    ico.inputs['Subdivisions'].default_value = 1

    instance_node = ng.nodes.new('GeometryNodeInstanceOnPoints')
    instance_node.location = (350, 0)
    ng.links.new(distribute.outputs['Points'], instance_node.inputs['Points'])
    ng.links.new(ico.outputs['Mesh'], instance_node.inputs['Instance'])

    # Scale instances
    combine_scale = ng.nodes.new('ShaderNodeCombineXYZ')
    combine_scale.location = (200, -150)
    ng.links.new(input_node.outputs['Scale'], combine_scale.inputs['X'])
    ng.links.new(input_node.outputs['Scale'], combine_scale.inputs['Y'])
    ng.links.new(input_node.outputs['Scale'], combine_scale.inputs['Z'])
    ng.links.new(combine_scale.outputs['Vector'], instance_node.inputs['Scale'])

    # Realize instances
    realize = ng.nodes.new('GeometryNodeRealizeInstances')
    realize.location = (550, 0)
    ng.links.new(instance_node.outputs['Instances'], realize.inputs['Geometry'])

    # Join with original
    join = ng.nodes.new('GeometryNodeJoinGeometry')
    join.location = (750, 0)
    ng.links.new(input_node.outputs['Geometry'], join.inputs['Geometry'])
    ng.links.new(realize.outputs['Geometry'], join.inputs['Geometry'])

    ng.links.new(join.outputs['Geometry'], output_node.inputs['Geometry'])

    return ng


def create_smooth_deform_group() -> bpy.types.NodeTree:
    """Create a GN group for smooth spherical expansion/contraction.

    Inputs:
        - Geometry
        - Factor (float, keyframed: amount of spherical push)
    """
    name = _GN_PREFIX + "Smooth_Deform"

    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]

    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.nodes.clear()

    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'INPUT')
    _add_interface_socket(ng, "Factor", 'NodeSocketFloat', 'INPUT', default=0.0, min_value=-2.0, max_value=2.0)
    _add_interface_socket(ng, "Geometry", 'NodeSocketGeometry', 'OUTPUT')

    input_node, output_node = _ensure_group_io(ng)

    # Normal
    normal_node = ng.nodes.new('GeometryNodeInputNormal')
    normal_node.location = (-100, -150)

    # Scale normal by Factor
    scale_node = ng.nodes.new('ShaderNodeVectorMath')
    scale_node.operation = 'SCALE'
    scale_node.location = (100, -100)
    ng.links.new(normal_node.outputs['Normal'], scale_node.inputs[0])
    ng.links.new(input_node.outputs['Factor'], scale_node.inputs['Scale'])

    # Set Position (offset)
    set_pos = ng.nodes.new('GeometryNodeSetPosition')
    set_pos.location = (300, 0)
    ng.links.new(input_node.outputs['Geometry'], set_pos.inputs['Geometry'])
    ng.links.new(scale_node.outputs['Vector'], set_pos.inputs['Offset'])

    ng.links.new(set_pos.outputs['Geometry'], output_node.inputs['Geometry'])

    return ng


# =============================================================================
# Geometry Nodes Animation Application
# =============================================================================

# Map of preset IDs to their builder functions and keyframe configs
GN_PRESETS = {
    'GN_WAVE_DEFORM': {
        'name': "Wave Deform",
        'icon': "MOD_WAVE",
        'description': "Animated sine-wave deformation along geometry",
        'builder': create_wave_deform_group,
        'keyframes': {
            # socket_name: [(frame_offset, value), ...]
            'Amplitude': [(0, 0.0), (0.3, 1.0), (0.7, 1.0), (1.0, 0.0)],
            'Phase': [(0, 0.0), (1.0, 12.56)],  # 2 full cycles
        },
    },
    'GN_NOISE_DISPLACE': {
        'name': "Noise Displacement",
        'icon': "MOD_DISPLACE",
        'description': "Procedural noise-driven vertex displacement",
        'builder': create_noise_displacement_group,
        'keyframes': {
            'Strength': [(0, 0.0), (0.25, 0.8), (0.75, 0.8), (1.0, 0.0)],
            'Offset': [(0, 0.0), (1.0, 5.0)],
        },
    },
    'GN_DISSOLVE': {
        'name': "Dissolve",
        'icon': "MOD_PARTICLE_INSTANCE",
        'description': "Progressive random face deletion (dissolve effect)",
        'builder': create_dissolve_group,
        'keyframes': {
            'Factor': [(0, 0.0), (0.8, 0.9), (1.0, 1.0)],
        },
    },
    'GN_SCATTER': {
        'name': "Scatter Grow",
        'icon': "OUTLINER_OB_POINTCLOUD",
        'description': "Animated particle scatter growing on surface",
        'builder': create_scatter_instances_group,
        'keyframes': {
            'Density': [(0, 0.0), (0.5, 50.0), (1.0, 50.0)],
            'Scale': [(0, 0.001), (0.3, 0.05), (1.0, 0.1)],
        },
    },
    'GN_SMOOTH_DEFORM': {
        'name': "Smooth Inflate",
        'icon': "MOD_SMOOTH",
        'description': "Smooth spherical inflation/deflation of mesh",
        'builder': create_smooth_deform_group,
        'keyframes': {
            'Factor': [(0, 0.0), (0.3, 0.5), (0.7, 0.5), (1.0, 0.0)],
        },
    },
}


def apply_gn_preset(obj, preset_id: str, start_frame: int, duration: int, props) -> bool:
    """Apply a Geometry Nodes animation preset to an object.

    Creates/reuses the node group, adds a modifier, and keyframes the inputs.
    Returns True on success.
    """
    preset_config = GN_PRESETS.get(preset_id)
    if not preset_config:
        return False

    # Build or reuse the node group
    node_group = preset_config['builder']()

    # Add modifier
    modifier_name = f"VA_{preset_config['name'].replace(' ', '_')}"

    # Remove existing modifier of same name if present
    if modifier_name in obj.modifiers:
        obj.modifiers.remove(obj.modifiers[modifier_name])

    mod = obj.modifiers.new(name=modifier_name, type='NODES')
    mod.node_group = node_group

    # Find socket identifiers for keyframing
    # In Blender 4.0+, modifier inputs are accessed by socket identifier
    socket_id_map = {}
    for item in node_group.interface.items_tree:
        if hasattr(item, 'in_out') and item.in_out == 'INPUT':
            if hasattr(item, 'socket_type') and item.socket_type != 'NodeSocketGeometry':
                socket_id_map[item.name] = item.identifier

    # Apply keyframes
    keyframe_config = preset_config['keyframes']
    end_frame = start_frame + duration

    for socket_name, keyframes in keyframe_config.items():
        identifier = socket_id_map.get(socket_name)
        if not identifier:
            continue

        for fraction, value in keyframes:
            frame = int(start_frame + fraction * duration)
            # Set the value
            mod[identifier] = value
            # Insert keyframe
            mod.keyframe_insert(
                data_path=f'["{identifier}"]',
                frame=frame,
            )

    # Apply easing to the GN keyframes
    if obj.animation_data and obj.animation_data.action:
        for fcurve in obj.animation_data.action.fcurves:
            if modifier_name in fcurve.data_path or 'VA_' in fcurve.data_path:
                for kf in fcurve.keyframe_points:
                    kf.interpolation = props.preset_animation_interpolation
                    kf.easing = props.preset_animation_easing

    return True


def remove_gn_presets_from_object(obj):
    """Remove all VectArt GN modifiers from an object."""
    mods_to_remove = [m for m in obj.modifiers if m.name.startswith("VA_")]
    for mod in mods_to_remove:
        obj.modifiers.remove(mod)


def cleanup_unused_gn_groups():
    """Remove any VectArt GN node groups with zero users."""
    for ng in list(bpy.data.node_groups):
        if ng.name.startswith(_GN_PREFIX) and ng.users == 0:
            bpy.data.node_groups.remove(ng)
