# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025 Dimona Patrick, Dream-Pixels-Forge

"""Operator definitions for VectArt Animation."""

from __future__ import annotations

import random
import time

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Operator
from mathutils import Vector, Euler

from .utils import (
    apply_preset_animation,
    calculate_sequence_timing,
    get_safe_position,
)


# =============================================================================
# Collection Operators
# =============================================================================


class VECTART_OT_AddCollection(Operator):
    """Add the active collection to the animation list"""

    bl_idname = "vectart.add_collection"
    bl_label = "Add Collection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not context.collection:
            return False
        props = context.scene.vectart_animation_props
        return not any(item.collection == context.collection for item in props.collections)

    def execute(self, context):
        props = context.scene.vectart_animation_props
        active_collection = context.collection

        if not active_collection:
            self.report({'WARNING'}, "No active collection to add")
            return {'CANCELLED'}

        item = props.collections.add()
        item.collection = active_collection
        item.name = active_collection.name
        item.active = True
        props.active_collection_index = len(props.collections) - 1

        self.report({'INFO'}, f"Added collection: {active_collection.name}")
        return {'FINISHED'}


class VECTART_OT_RemoveCollection(Operator):
    """Remove the selected collection from the animation list"""

    bl_idname = "vectart.remove_collection"
    bl_label = "Remove Collection"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = context.scene.vectart_animation_props
        return (
            props.collections
            and 0 <= props.active_collection_index < len(props.collections)
        )

    def execute(self, context):
        props = context.scene.vectart_animation_props
        index = props.active_collection_index

        try:
            collection_name = props.collections[index].collection.name
            props.collections.remove(index)
            if props.collections:
                props.active_collection_index = min(index, len(props.collections) - 1)
            else:
                props.active_collection_index = 0
            self.report({'INFO'}, f"Removed collection: {collection_name}")
            return {'FINISHED'}
        except (IndexError, AttributeError) as e:
            self.report({'ERROR'}, f"Error removing collection: {e}")
            return {'CANCELLED'}


class VECTART_OT_ClearCollections(Operator):
    """Remove all collections from the animation list"""

    bl_idname = "vectart.clear_collections"
    bl_label = "Clear Collections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vectart_animation_props
        props.collections.clear()
        return {'FINISHED'}


class VECTART_OT_RefreshCollections(Operator):
    """Refresh the collection list from scene data"""

    bl_idname = "vectart.refresh_collections"
    bl_label = "Refresh Collections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vectart_animation_props
        props.collections.clear()

        excluded_names = {"cameras", "lights", "bg"}
        for collection in bpy.data.collections:
            if collection.name.lower() in excluded_names:
                continue
            item = props.collections.add()
            item.name = collection.name
            item.collection = collection

        return {'FINISHED'}


class VECTART_OT_SelectCollectionObjects(Operator):
    """Select objects in the active collection by type"""

    bl_idname = "vectart.select_collection_objects"
    bl_label = "Select Objects"
    bl_options = {'REGISTER', 'UNDO'}

    select_type: EnumProperty(
        items=[
            ('ALL', "All", "Select all objects"),
            ('CURVES', "Curves", "Select only curves"),
            ('MESHES', "Meshes", "Select only meshes"),
        ],
        default='ALL',
    )  # type: ignore[assignment]

    def execute(self, context):
        props = context.scene.vectart_animation_props
        if props.active_collection_index < 0:
            return {'CANCELLED'}

        collection_item = props.collections[props.active_collection_index]
        if not collection_item.collection:
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        for obj in collection_item.collection.objects:
            if (
                self.select_type == 'ALL'
                or (self.select_type == 'CURVES' and obj.type == 'CURVE')
                or (self.select_type == 'MESHES' and obj.type == 'MESH')
            ):
                obj.select_set(True)
                context.view_layer.objects.active = obj

        return {'FINISHED'}



# =============================================================================
# Animation Operators
# =============================================================================


class VECTART_OT_DefaultAnimation(Operator):
    """Create animation based on current settings for the active collection"""

    bl_idname = "vectart.default_animation"
    bl_label = "Create Animation"
    bl_options = {'REGISTER', 'UNDO'}

    def _get_sorted_objects(self, context, objects):
        """Sort objects based on layer order setting."""
        props = context.scene.vectart_animation_props
        valid = [obj for obj in objects if obj.type in {'MESH', 'CURVE'}]
        if props.layer_animation_order == 'TOP_DOWN':
            valid.sort(key=lambda o: o.location.z, reverse=True)
        elif props.layer_animation_order == 'BOTTOM_UP':
            valid.sort(key=lambda o: o.location.z)
        return valid

    def _calculate_delays(self, props, object_count: int) -> list[int]:
        """Calculate per-object delays for orchestral timing."""
        delays = [0] * object_count
        if props.delay_mode == 'NONE':
            return delays
        elif props.delay_mode == 'SEQUENTIAL':
            for i in range(object_count):
                delays[i] = int(round(i * props.delay_amount))
        elif props.delay_mode == 'OVERLAP':
            overlap = max(0.0, min(props.musicality, 1.0))
            overlap_factor = props.delay_amount * (1.0 - overlap)
            for i in range(object_count):
                delays[i] = int(round(i * overlap_factor))
        elif props.delay_mode == 'RANDOM':
            random.seed(props.random_seed)
            max_delay = props.delay_amount * object_count * max(0.1, props.musicality)
            for i in range(object_count):
                delays[i] = int(round(random.uniform(0, max_delay)))
        return delays

    # -- Individual animation creators --

    def _create_scale_animation(self, obj, props, start_frame, end_frame):
        original_scale = obj.scale.copy()
        obj.scale = Vector((0.001, 0.001, 0.001))
        obj.keyframe_insert(data_path="scale", frame=start_frame)

        final_scale = Vector(props.scale_final) if obj.type == 'CURVE' else original_scale
        obj.scale = final_scale
        obj.keyframe_insert(data_path="scale", frame=end_frame)
        self._apply_easing(obj, props, "scale")

    def _create_rotate_animation(self, obj, props, start_frame, end_frame):
        initial_rotation = obj.rotation_euler.copy()
        obj.keyframe_insert(data_path="rotation_euler", frame=start_frame)

        final_rotation = initial_rotation.copy()
        angle = props.rotation_angle
        if props.rotation_direction == 'CCW':
            angle = -angle
        axis_map = {'X': 0, 'Y': 1, 'Z': 2}
        final_rotation[axis_map[props.rotation_axis]] += angle

        obj.rotation_euler = final_rotation
        obj.keyframe_insert(data_path="rotation_euler", frame=end_frame)
        self._apply_easing(obj, props, "rotation_euler")

    def _create_location_animation(self, obj, props, start_frame, end_frame):
        original_loc = obj.location.copy()
        if props.use_relative_location:
            start_pos = original_loc + Vector(props.location_start)
            end_pos = original_loc + Vector(props.location_end)
        else:
            start_pos = Vector(props.location_start)
            end_pos = Vector(props.location_end)

        obj.location = start_pos
        obj.keyframe_insert(data_path="location", frame=start_frame)
        obj.location = end_pos
        obj.keyframe_insert(data_path="location", frame=end_frame)
        self._apply_easing(obj, props, "location")

    def _create_extrude_animation(self, obj, props, start_frame, end_frame):
        if obj.type != 'CURVE':
            return
        obj.data.extrude = props.extrude_start
        obj.data.keyframe_insert(data_path="extrude", frame=start_frame)
        obj.data.extrude = props.extrude_end
        obj.data.keyframe_insert(data_path="extrude", frame=end_frame)

        if obj.data.animation_data and obj.data.animation_data.action:
            for fcurve in obj.data.animation_data.action.fcurves:
                if fcurve.data_path == "extrude":
                    for kf in fcurve.keyframe_points:
                        kf.interpolation = props.preset_animation_interpolation
                        kf.easing = props.preset_animation_easing

    def _apply_easing(self, obj, props, data_path: str):
        """Apply interpolation and easing to fcurves matching *data_path*."""
        if not (obj.animation_data and obj.animation_data.action):
            return
        for fcurve in obj.animation_data.action.fcurves:
            if fcurve.data_path == data_path:
                for kf in fcurve.keyframe_points:
                    kf.interpolation = props.preset_animation_interpolation
                    kf.easing = props.preset_animation_easing

    def _create_object_animation(self, obj, props, start_frame, end_frame):
        """Create all enabled animations for a single object."""
        obj.animation_data_clear()
        obj.animation_data_create()

        created = False
        if props.use_scale:
            self._create_scale_animation(obj, props, start_frame + props.scale_offset, end_frame + props.scale_offset)
            created = True
        if props.use_rotation:
            self._create_rotate_animation(obj, props, start_frame + props.rotation_offset, end_frame + props.rotation_offset)
            created = True
        if props.use_location:
            self._create_location_animation(obj, props, start_frame + props.location_offset, end_frame + props.location_offset)
            created = True
        if props.use_extrude and obj.type == 'CURVE':
            self._create_extrude_animation(obj, props, start_frame + props.extrude_offset, end_frame + props.extrude_offset)
            created = True
        if not created:
            self._create_scale_animation(obj, props, start_frame, end_frame)

    def execute(self, context):
        props = context.scene.vectart_animation_props

        if props.active_collection_index < 0:
            self.report({'WARNING'}, "No collection selected")
            return {'CANCELLED'}

        collection_item = props.collections[props.active_collection_index]
        if not collection_item.collection:
            self.report({'WARNING'}, "Invalid collection")
            return {'CANCELLED'}

        objects = self._get_sorted_objects(context, collection_item.collection.objects)
        if not objects:
            self.report({'WARNING'}, "No animatable objects in collection")
            return {'CANCELLED'}

        try:
            object_duration = props.frames_per_object if props.auto_duration else props.duration
            delays = self._calculate_delays(props, len(objects))
            animated_objects: list = []

            for i, obj in enumerate(objects):
                start_frame = int(round(props.animation_start_frame + delays[i]))
                end_frame = int(round(start_frame + object_duration))
                obj["animation_index"] = i

                if props.use_collision_detection and animated_objects:
                    other_objs = [o for o in objects if o != obj]
                    safe_pos = get_safe_position(obj, obj.location, other_objs, props.collision_margin)
                    if (safe_pos - obj.location).length > 1e-6:
                        obj.location = safe_pos

                self._create_object_animation(obj, props, start_frame, end_frame)
                animated_objects.append(obj)

            context.scene.frame_current = props.animation_start_frame
            for area in context.screen.areas:
                if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                    area.tag_redraw()

            self.report({'INFO'}, "Animation created successfully")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Error creating animation: {e}")
            return {'CANCELLED'}



class VECTART_OT_PresetAnimation(Operator):
    """Create animation using the selected preset for the active collection"""

    bl_idname = "vectart.preset_animation"
    bl_label = "Create Preset Animation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vectart_animation_props

        if props.active_collection_index < 0:
            self.report({'WARNING'}, "No collection selected")
            return {'CANCELLED'}

        collection_item = props.collections[props.active_collection_index]
        if not collection_item.collection:
            self.report({'WARNING'}, "Invalid collection")
            return {'CANCELLED'}

        valid_objects = [obj for obj in collection_item.collection.objects if obj.type in {'MESH', 'CURVE'}]

        if props.layer_animation_order == 'TOP_DOWN':
            objects = sorted(valid_objects, key=lambda o: o.location.z, reverse=True)
        elif props.layer_animation_order == 'BOTTOM_UP':
            objects = sorted(valid_objects, key=lambda o: o.location.z)
        else:
            objects = valid_objects

        if not objects:
            self.report({'WARNING'}, "No animatable objects in collection")
            return {'CANCELLED'}

        try:
            for i, obj in enumerate(objects):
                obj["animation_index"] = i
                current_delay = calculate_sequence_timing(props, i, len(objects))
                obj_start = props.animation_start_frame + int(current_delay)

                if props.use_collision_detection:
                    other_objs = [o for o in objects if o != obj]
                    safe_pos = get_safe_position(obj, obj.location, other_objs, props.collision_margin)
                    if (safe_pos - obj.location).length > 1e-6:
                        obj.location = safe_pos

                apply_preset_animation(self, context, obj, obj_start, props.animation_preset)

            context.scene.frame_current = props.animation_start_frame
            for area in context.screen.areas:
                if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                    area.tag_redraw()

            self.report({'INFO'}, "Preset animation created successfully")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Animation creation failed: {e}")
            return {'CANCELLED'}


class VECTART_OT_ApplyPreset(Operator):
    """Apply the selected animation preset to the currently selected objects"""

    bl_idname = "vectart.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def execute(self, context):
        props = context.scene.vectart_animation_props

        if not props.presets or props.active_preset_index < 0:
            self.report({'WARNING'}, "No preset selected")
            return {'CANCELLED'}

        preset_id = props.presets[props.active_preset_index].preset_id

        if props.delay_mode == 'RANDOM':
            props.random_seed = int(time.time())

        delays = VECTART_OT_DefaultAnimation._calculate_delays(
            VECTART_OT_DefaultAnimation, props, len(context.selected_objects)
        )

        for i, obj in enumerate(context.selected_objects):
            start_frame = props.animation_start_frame + delays[i]
            apply_preset_animation(self, context, obj, start_frame, preset_id)

        self.report({'INFO'}, f"Applied preset to {len(context.selected_objects)} objects")
        return {'FINISHED'}


class VECTART_OT_RefreshPresets(Operator):
    """Refresh the animation presets list"""

    bl_idname = "vectart.refresh_presets"
    bl_label = "Refresh Presets"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.vectart_animation_props
        props.presets.clear()

        preset_data = [
            ("ROBOTIC_UNFOLD", "Robotic Unfold", "MESH_CUBE", "Robotic unfolding animation with multi-step transforms"),
            ("ROBOTIC_TRANSFORM", "Robotic Transform", "MESH_CYLINDER", "Complex multi-axis transformation sequence"),
            ("TECH_ASSEMBLY", "Tech Assembly", "MESH_GRID", "Technical assembly with fly-in and snap"),
            ("MECH_STARTUP", "Mech Startup", "MESH_MONKEY", "Mechanical startup with bounce vibration"),
            ("ORIGAMI", "Origami", "ORIENTATION_LOCAL", "Complex origami folding and unfolding"),
            ("HOLOGRAPHIC_APPEAR", "Holographic", "LIGHT_POINT", "Holographic scan-line appearance"),
            ("GLITCH_APPEAR", "Glitch", "MOD_NOISE", "Glitchy random teleport appearance"),
            ("ASSEMBLE", "Assemble", "MOD_BUILD", "Dramatic assembly from scattered pieces"),
            ("MAGNETIC", "Magnetic", "FORCE_MAGNETIC", "Magnetic snap with bounce overshoot"),
            ("EXPLODE", "Explode", "MOD_EXPLODE", "Explosive scatter and fade-out"),
            ("TYPEWRITER", "Typewriter", "SMALL_CAPS", "Quick stamp-in like typewriter keys"),
            ("SPIRAL_IN", "Spiral In", "FORCE_VORTEX", "Spiral inward with rotation"),
            ("BOUNCE_DROP", "Bounce Drop", "FORCE_DRAG", "Drop from above with squash-stretch bounce"),
            ("ELASTIC_POP", "Elastic Pop", "FORCE_LENNARDJONES", "Pop-in with elastic overshoot"),
            ("DOMINO_FALL", "Domino Fall", "EMPTY_SINGLE_ARROW", "Sequential domino-style topple"),
        ]

        for preset_id, name, icon, desc in preset_data:
            item = props.presets.add()
            item.name = name
            item.preset_id = preset_id
            item.icon = icon
            item.description = desc

        self.report({'INFO'}, f"Loaded {len(preset_data)} animation presets")
        return {'FINISHED'}



# =============================================================================
# Keyframe & Utility Operators
# =============================================================================


class VECTART_OT_CopyKeyframes(Operator):
    """Copy keyframes from all selected objects"""

    bl_idname = "vectart.copy_keyframes"
    bl_label = "Copy Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(
            obj.animation_data for obj in context.selected_objects
        )

    def execute(self, context):
        all_keyframe_data = {}

        for obj in context.selected_objects:
            if not obj.animation_data or not obj.animation_data.action:
                continue

            keyframe_data = []
            for fcurve in obj.animation_data.action.fcurves:
                curve_data = {
                    'data_path': fcurve.data_path,
                    'array_index': fcurve.array_index,
                    'keyframes': [],
                }
                for kf in fcurve.keyframe_points:
                    curve_data['keyframes'].append({
                        'co': kf.co[:],
                        'handle_left': kf.handle_left[:],
                        'handle_right': kf.handle_right[:],
                        'interpolation': kf.interpolation,
                        'easing': kf.easing,
                    })
                keyframe_data.append(curve_data)

            if keyframe_data:
                all_keyframe_data[obj.name] = keyframe_data

        if not all_keyframe_data:
            self.report({'WARNING'}, "No animation data to copy")
            return {'CANCELLED'}

        context.scene['vectart_copied_keyframes'] = all_keyframe_data
        self.report({'INFO'}, f"Keyframes copied from {len(all_keyframe_data)} objects")
        return {'FINISHED'}


class VECTART_OT_PasteKeyframesReverse(Operator):
    """Paste previously copied keyframes in reverse order"""

    bl_idname = "vectart.paste_keyframes_reverse"
    bl_label = "Paste Keyframes Reversed"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.selected_objects
            and 'vectart_copied_keyframes' in context.scene
        )

    def execute(self, context):
        props = context.scene.vectart_animation_props
        all_keyframe_data = context.scene['vectart_copied_keyframes']

        if not all_keyframe_data:
            self.report({'WARNING'}, "No keyframes to paste")
            return {'CANCELLED'}

        source_names = list(all_keyframe_data.keys())
        pasted_count = 0

        for obj in context.selected_objects:
            source_name = obj.name if obj.name in source_names else source_names[0]
            keyframe_data = all_keyframe_data[source_name]

            if not obj.animation_data:
                obj.animation_data_create()
            if not obj.animation_data.action:
                obj.animation_data.action = bpy.data.actions.new(name=f"{obj.name}_Action")

            all_times = [kf['co'][0] for curve in keyframe_data for kf in curve['keyframes']]
            if not all_times:
                continue

            original_end = max(all_times)

            for curve_data in keyframe_data:
                fcurve = obj.animation_data.action.fcurves.find(
                    curve_data['data_path'],
                    index=curve_data['array_index'],
                )
                if not fcurve:
                    fcurve = obj.animation_data.action.fcurves.new(
                        data_path=curve_data['data_path'],
                        index=curve_data['array_index'],
                    )

                for kf_data in reversed(curve_data['keyframes']):
                    original_time = kf_data['co'][0]
                    reversed_time = props.paste_target_frame + (original_end - original_time)
                    keyframe = fcurve.keyframe_points.insert(reversed_time, kf_data['co'][1])
                    keyframe.interpolation = kf_data['interpolation']
                    if 'easing' in kf_data:
                        keyframe.easing = kf_data['easing']

            pasted_count += 1

        self.report({'INFO'}, f"Keyframes pasted in reverse to {pasted_count} objects")
        return {'FINISHED'}


class VECTART_OT_InitializeObjects(Operator):
    """Store original transform values for the selected objects"""

    bl_idname = "vectart.initialize_objects"
    bl_label = "Store Transforms"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            obj["original_location"] = list(obj.location)
            obj["original_rotation"] = list(obj.rotation_euler)
            obj["original_scale"] = list(obj.scale)
            if obj.type == 'CURVE':
                if hasattr(obj.data, "extrude"):
                    obj["original_extrude"] = obj.data.extrude
                if hasattr(obj.data, "bevel_depth"):
                    obj["original_bevel_depth"] = obj.data.bevel_depth
            count += 1

        self.report({'INFO'}, f"Stored transforms for {count} objects")
        return {'FINISHED'}


class VECTART_OT_ClearAnimation(Operator):
    """Clear animation data and optionally restore original transforms"""

    bl_idname = "vectart.clear_animation"
    bl_label = "Clear Animation"
    bl_options = {'REGISTER', 'UNDO'}

    restore_location: BoolProperty(name="Restore Location", default=True)  # type: ignore[assignment]
    restore_rotation: BoolProperty(name="Restore Rotation", default=True)  # type: ignore[assignment]
    restore_scale: BoolProperty(name="Restore Scale", default=True)  # type: ignore[assignment]
    restore_extrude: BoolProperty(name="Restore Extrude", default=True)  # type: ignore[assignment]
    clear_all: BoolProperty(name="Clear All Animation Data", default=False)  # type: ignore[assignment]

    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(
            obj.animation_data for obj in context.selected_objects
        )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "clear_all")
        if not self.clear_all:
            box = layout.box()
            box.label(text="Restore Properties:")
            box.prop(self, "restore_location")
            box.prop(self, "restore_rotation")
            box.prop(self, "restore_scale")
            if any(obj.type == 'CURVE' for obj in context.selected_objects):
                box.prop(self, "restore_extrude")

    def _restore_object_state(self, obj):
        if self.restore_location and "original_location" in obj:
            obj.location = Vector(obj["original_location"])
        if self.restore_rotation and "original_rotation" in obj:
            obj.rotation_euler = Euler(obj["original_rotation"])
        if self.restore_scale and "original_scale" in obj:
            obj.scale = Vector(obj["original_scale"])
        if obj.type == 'CURVE':
            if self.restore_extrude and "original_extrude" in obj:
                obj.data.extrude = obj["original_extrude"]
            if "original_bevel_depth" in obj:
                obj.data.bevel_depth = obj["original_bevel_depth"]

    def _clear_animation_data(self, obj):
        if self.clear_all:
            if obj.animation_data:
                obj.animation_data_clear()
            if obj.type == 'CURVE' and obj.data.animation_data:
                obj.data.animation_data_clear()
            return

        if obj.animation_data and obj.animation_data.action:
            fcurves_to_remove = []
            for fc in obj.animation_data.action.fcurves:
                if (
                    (self.restore_location and fc.data_path.startswith("location"))
                    or (self.restore_rotation and fc.data_path.startswith("rotation"))
                    or (self.restore_scale and fc.data_path.startswith("scale"))
                ):
                    fcurves_to_remove.append(fc)
            for fc in fcurves_to_remove:
                obj.animation_data.action.fcurves.remove(fc)
            if not obj.animation_data.action.fcurves:
                obj.animation_data_clear()

        if obj.type == 'CURVE' and obj.data.animation_data and obj.data.animation_data.action:
            fcurves_to_remove = []
            for fc in obj.data.animation_data.action.fcurves:
                if (
                    (self.restore_extrude and fc.data_path.startswith("extrude"))
                    or fc.data_path.startswith("bevel_depth")
                ):
                    fcurves_to_remove.append(fc)
            for fc in fcurves_to_remove:
                obj.data.animation_data.action.fcurves.remove(fc)
            if not obj.data.animation_data.action.fcurves:
                obj.data.animation_data_clear()

    def execute(self, context):
        cleared = 0
        for obj in context.selected_objects:
            if obj.animation_data:
                self._clear_animation_data(obj)
                self._restore_object_state(obj)
                cleared += 1

        context.view_layer.update()
        self.report({'INFO'}, f"Cleared animation for {cleared} objects")
        return {'FINISHED'}


# =============================================================================
# Geometry Nodes Operators
# =============================================================================


class VECTART_OT_ApplyGNPreset(Operator):
    """Apply a geometry nodes animation preset to selected objects"""

    bl_idname = "vectart.apply_gn_preset"
    bl_label = "Apply GN Preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def execute(self, context):
        from .geometry_nodes import apply_gn_preset

        props = context.scene.vectart_animation_props
        preset_id = props.gn_preset
        start_frame = props.animation_start_frame
        duration = props.gn_duration

        count = 0
        for i, obj in enumerate(context.selected_objects):
            if obj.type != 'MESH':
                continue
            obj_start = start_frame + int(i * props.delay_amount) if props.delay_mode == 'SEQUENTIAL' else start_frame
            if apply_gn_preset(obj, preset_id, obj_start, duration, props):
                count += 1

        if count == 0:
            self.report({'WARNING'}, "No mesh objects to apply GN preset to")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Applied GN preset to {count} objects")
        return {'FINISHED'}


class VECTART_OT_RemoveGNPresets(Operator):
    """Remove all VectArt geometry node modifiers from selected objects"""

    bl_idname = "vectart.remove_gn_presets"
    bl_label = "Remove GN Effects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.selected_objects and any(
            any(m.name.startswith("VA_") for m in obj.modifiers)
            for obj in context.selected_objects
        )

    def execute(self, context):
        from .geometry_nodes import remove_gn_presets_from_object, cleanup_unused_gn_groups

        count = 0
        for obj in context.selected_objects:
            mods_before = len(obj.modifiers)
            remove_gn_presets_from_object(obj)
            if len(obj.modifiers) < mods_before:
                count += 1

        cleanup_unused_gn_groups()
        self.report({'INFO'}, f"Removed GN effects from {count} objects")
        return {'FINISHED'}


# =============================================================================
# Registration
# =============================================================================

_classes = (
    VECTART_OT_AddCollection,
    VECTART_OT_RemoveCollection,
    VECTART_OT_ClearCollections,
    VECTART_OT_RefreshCollections,
    VECTART_OT_SelectCollectionObjects,
    VECTART_OT_DefaultAnimation,
    VECTART_OT_PresetAnimation,
    VECTART_OT_ApplyPreset,
    VECTART_OT_RefreshPresets,
    VECTART_OT_CopyKeyframes,
    VECTART_OT_PasteKeyframesReverse,
    VECTART_OT_InitializeObjects,
    VECTART_OT_ClearAnimation,
    VECTART_OT_ApplyGNPreset,
    VECTART_OT_RemoveGNPresets,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
